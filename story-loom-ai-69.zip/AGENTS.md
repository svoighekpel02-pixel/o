<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Architecture rules
- Panels are remote image URLs extracted by `src/lib/extract.functions.ts` and always rendered through the `/api/img` proxy — CDNs block hotlinking and the canvas player needs same-origin images.
- Script generation and panel matching are local, deterministic code in `src/lib/script-engine.ts` — the user forbids paid/external APIs.
- Narration uses free Edge neural TTS via `src/lib/edge-tts.ts` (server function `tts.functions.ts`, no keys); Player mixes it with Web Audio and exports via MediaRecorder — user forbids paid APIs and wants downloadable videos.
- Narration presets and input validation live in a browser-safe narration module; use returned word marks and decoded audio durations for captions, cuts and FX so voice prosody cannot desynchronize exports.
- Reference templates persist in browser storage and use explicit beat placeholders rather than automatically interpreting pasted scripts; this keeps adaptation deterministic and independent of paid APIs.
