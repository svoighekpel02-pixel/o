import { DEFAULT_PREFS, type Prefs, type Video } from "./script-engine";

/** Browser-only persistence: generated videos, learned preferences, finished renders. */
const VKEY = "samumanga:videos";
const PKEY = "samumanga:prefs";

export function loadVideos(): Video[] {
  try { return JSON.parse(localStorage.getItem(VKEY) || "[]"); } catch { return []; }
}
export function saveVideos(list: Video[]) {
  localStorage.setItem(VKEY, JSON.stringify(list.slice(-200)));
}
export function upsertVideos(vs: Video[]) {
  const ids = new Set(vs.map((v) => v.id));
  saveVideos([...loadVideos().filter((v) => !ids.has(v.id)), ...vs]);
}
export function removeVideo(id: string) {
  saveVideos(loadVideos().filter((v) => v.id !== id));
  deleteRender(id).catch(() => {});
}

export function loadPrefs(): Prefs {
  try { return { ...DEFAULT_PREFS, ...JSON.parse(localStorage.getItem(PKEY) || "{}") }; } catch { return DEFAULT_PREFS; }
}
export function savePrefs(p: Prefs) {
  localStorage.setItem(PKEY, JSON.stringify(p));
}

// ---- Rendered files (IndexedDB) ----
export type Render = { id: string; videoId: string; title: string; filename: string; blob: Blob; createdAt: number };
function db(): Promise<IDBDatabase> {
  return new Promise((ok, ko) => {
    const r = indexedDB.open("samumanga", 1);
    r.onupgradeneeded = () => r.result.createObjectStore("renders", { keyPath: "videoId" });
    r.onsuccess = () => ok(r.result);
    r.onerror = () => ko(r.error);
  });
}
async function tx<T>(mode: IDBTransactionMode, fn: (s: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  const d = await db();
  return new Promise((ok, ko) => {
    const req = fn(d.transaction("renders", mode).objectStore("renders"));
    req.onsuccess = () => ok(req.result);
    req.onerror = () => ko(req.error);
  });
}
export const saveRender = (r: Render) => tx("readwrite", (s) => s.put(r));
export const listRenders = () => tx<Render[]>("readonly", (s) => s.getAll() as IDBRequest<Render[]>);
export const deleteRender = (videoId: string) => tx("readwrite", (s) => s.delete(videoId));
