export type SeasonId = "all" | "halloween" | "navidad" | "san_valentin" | "ano_nuevo" | "verano";

export type Season = {
  id: SeasonId;
  label: string;
  keywords: string[];
  months: number[];
};

export const SEASONS: Season[] = [
  { id: "all", label: "Todas las temporadas", keywords: [], months: [] },
  {
    id: "halloween",
    label: "Halloween",
    keywords: ["halloween", "terror", "monstruo", "fantasma", "bruja"],
    months: [9, 10],
  },
  {
    id: "navidad",
    label: "Navidad",
    keywords: ["navidad", "invierno", "nieve", "regalo", "familia"],
    months: [11],
  },
  {
    id: "san_valentin",
    label: "San Valentín",
    keywords: ["amor", "romance", "pareja", "san valentin"],
    months: [1],
  },
  {
    id: "ano_nuevo",
    label: "Año nuevo",
    keywords: ["ano nuevo", "año nuevo", "proposito", "renacer"],
    months: [0],
  },
  {
    id: "verano",
    label: "Verano",
    keywords: ["verano", "playa", "vacaciones", "festival"],
    months: [5, 6, 7],
  },
];

export function currentSeason(date = new Date()): SeasonId {
  const month = date.getMonth();
  return SEASONS.find((season) => season.months.includes(month))?.id ?? "all";
}

export function seasonLabel(id: SeasonId) {
  return SEASONS.find((season) => season.id === id)?.label ?? SEASONS[0]!.label;
}

const STORAGE_KEY = "samumanga:season";
export function loadSeason(): SeasonId {
  if (typeof window === "undefined") return "all";
  const value = window.localStorage.getItem(STORAGE_KEY) as SeasonId | null;
  return SEASONS.some((season) => season.id === value) ? value! : currentSeason();
}
export function saveSeason(id: SeasonId) {
  if (typeof window !== "undefined") window.localStorage.setItem(STORAGE_KEY, id);
}

export function matchesSeason(
  work: { season?: SeasonId | null; title: string; synopsis?: string; premise?: string },
  season: SeasonId,
) {
  if (season === "all") return true;
  if (work.season === season) return true;
  const haystack = `${work.title} ${work.synopsis ?? ""} ${work.premise ?? ""}`.toLocaleLowerCase();
  return (
    SEASONS.find((item) => item.id === season)?.keywords.some((keyword) =>
      haystack.includes(keyword),
    ) ?? false
  );
}
