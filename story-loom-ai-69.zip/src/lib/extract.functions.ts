import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { decode, parseChapterImages, UA } from "./chapter-parse";

/** Fetches a chapter page and returns its panel image URLs (in reading order). */
export const extractChapter = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => z.object({ url: z.string().url() }).parse(input))
  .handler(async ({ data }) => {
    const res = await fetch(data.url, {
      headers: { "User-Agent": UA, Accept: "text/html", "Accept-Language": "es-ES,es;q=0.9,en;q=0.8" },
      redirect: "follow",
    });
    if (!res.ok) {
      return { ok: false as const, error: `La página respondió con error ${res.status}.`, images: [], title: "", cover: "" };
    }
    const html = await res.text();
    const titleMatch =
      html.match(/<meta[^>]+property=["']og:title["'][^>]+content=["']([^"']+)/i) || html.match(/<title>([^<]+)<\/title>/i);
    const coverMatch = html.match(/<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)/i);
    const images = parseChapterImages(html, res.url || data.url);
    if (images.length === 0) {
      return { ok: false as const, error: "No encontré viñetas en esa página. Prueba con el enlace directo del capítulo.", images, title: "", cover: "" };
    }
    return { ok: true as const, error: "", images, title: decode(titleMatch?.[1] ?? "").trim(), cover: coverMatch?.[1] ?? images[0] ?? "" };
  });
