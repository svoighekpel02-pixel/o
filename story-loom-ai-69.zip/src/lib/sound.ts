/** Free, offline sound design: real bundled tracks plus procedural loops and cinematic FX (no APIs). */
import sexDrugs from "@/assets/music/sex-drugs-etc-slowed.mp3.asset.json";
import wokawona from "@/assets/music/wokawona-phonk.mp3.asset.json";

export type MusicStyle = "phonk" | "tension" | "epica";
/** Real MP3 tracks bundled with the app (selectable by id). */
export const REAL_TRACKS: Record<string, { url: string; label: string }> = {
  "real-sexdrugs": { url: sexDrugs.url, label: "🎵 Sex, Drugs, Etc. (slowed) – Beach Weather" },
  "real-wokawona": { url: wokawona.url, label: "🎵 Он гениален – WOKAWÓNA (phonk)" },
};
export const MUSIC_STYLES: { id: string; label: string }[] = [
  ...Object.entries(REAL_TRACKS).map(([id, t]) => ({ id, label: t.label })),
  { id: "phonk", label: "Phonk oscuro (cowbell + 808)" },
  { id: "tension", label: "Tensión / suspenso" },
  { id: "epica", label: "Épica de batalla" },
  { id: "ninguna", label: "Sin música" },
  { id: "archivo", label: "Mi propio archivo" },
];

function noiseBuffer(ac: BaseAudioContext, secs: number) {
  const b = ac.createBuffer(1, Math.ceil(ac.sampleRate * secs), ac.sampleRate);
  const d = b.getChannelData(0);
  for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
  return b;
}

function env(ac: BaseAudioContext, dest: AudioNode, t: number, peak: number, attack: number, decay: number) {
  const g = ac.createGain();
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(peak, t + attack);
  g.gain.exponentialRampToValueAtTime(0.0001, t + attack + decay);
  g.connect(dest);
  return g;
}

function kick(ac: BaseAudioContext, out: AudioNode, t: number, v = 1) {
  const o = ac.createOscillator();
  o.frequency.setValueAtTime(150, t);
  o.frequency.exponentialRampToValueAtTime(42, t + 0.12);
  o.connect(env(ac, out, t, 0.9 * v, 0.003, 0.35));
  o.start(t); o.stop(t + 0.4);
}
function bass808(ac: BaseAudioContext, out: AudioNode, t: number, f: number, len: number) {
  const o = ac.createOscillator();
  o.frequency.setValueAtTime(f * 1.5, t);
  o.frequency.exponentialRampToValueAtTime(f, t + 0.05);
  const sh = ac.createWaveShaper();
  const c = new Float32Array(256);
  for (let i = 0; i < 256; i++) { const x = i / 128 - 1; c[i] = Math.tanh(2.5 * x); }
  sh.curve = c;
  o.connect(sh);
  sh.connect(env(ac, out, t, 0.55, 0.005, len));
  o.start(t); o.stop(t + len + 0.05);
}
function cowbell(ac: BaseAudioContext, out: AudioNode, t: number, f: number) {
  const bp = ac.createBiquadFilter();
  bp.type = "bandpass"; bp.frequency.value = f * 1.4; bp.Q.value = 3;
  bp.connect(env(ac, out, t, 0.28, 0.002, 0.22));
  for (const m of [1, 1.48]) {
    const o = ac.createOscillator();
    o.type = "square"; o.frequency.value = f * m;
    o.connect(bp); o.start(t); o.stop(t + 0.3);
  }
}
function hat(ac: BaseAudioContext, out: AudioNode, t: number, nb: AudioBuffer, v = 0.12) {
  const s = ac.createBufferSource(); s.buffer = nb;
  const hp = ac.createBiquadFilter(); hp.type = "highpass"; hp.frequency.value = 7000;
  s.connect(hp); hp.connect(env(ac, out, t, v, 0.001, 0.05));
  s.start(t, Math.random()); s.stop(t + 0.08);
}
function snare(ac: BaseAudioContext, out: AudioNode, t: number, nb: AudioBuffer) {
  const s = ac.createBufferSource(); s.buffer = nb;
  const bp = ac.createBiquadFilter(); bp.type = "bandpass"; bp.frequency.value = 1800;
  s.connect(bp); bp.connect(env(ac, out, t, 0.45, 0.002, 0.18));
  s.start(t, Math.random()); s.stop(t + 0.25);
}
function pad(ac: BaseAudioContext, out: AudioNode, t: number, freqs: number[], len: number, v = 0.06) {
  const lp = ac.createBiquadFilter(); lp.type = "lowpass"; lp.frequency.value = 1200;
  const g = ac.createGain();
  g.gain.setValueAtTime(0.0001, t);
  g.gain.linearRampToValueAtTime(v, t + 0.4);
  g.gain.linearRampToValueAtTime(0.0001, t + len);
  lp.connect(g); g.connect(out);
  for (const f of freqs) for (const det of [-6, 6]) {
    const o = ac.createOscillator(); o.type = "sawtooth"; o.frequency.value = f; o.detune.value = det;
    o.connect(lp); o.start(t); o.stop(t + len + 0.05);
  }
}

const N = (semi: number) => 55 * Math.pow(2, semi / 12); // A1 based

/** Renders a loopable track (8 bars) for the given style. */
export async function renderMusic(style: MusicStyle): Promise<AudioBuffer> {
  const bpm = style === "phonk" ? 130 : style === "epica" ? 120 : 90;
  const beat = 60 / bpm;
  const bars = 8;
  const len = bars * 4 * beat;
  const ac = new OfflineAudioContext(2, Math.ceil(44100 * len), 44100);
  const master = ac.createGain(); master.gain.value = 0.8; master.connect(ac.destination);
  const nb = noiseBuffer(ac, 2);
  const prog = [0, 0, -4, -2, 0, 0, 3, -2]; // Am - F - G feel
  for (let bar = 0; bar < bars; bar++) {
    const b0 = bar * 4 * beat;
    const root = prog[bar]!;
    if (style === "phonk") {
      [0, 1.5, 2.5].forEach((q) => kick(ac, master, b0 + q * beat));
      [1, 3].forEach((q) => snare(ac, master, b0 + q * beat, nb));
      for (let s = 0; s < 16; s++) hat(ac, master, b0 + s * beat / 4, nb, s % 4 === 2 ? 0.16 : 0.08);
      bass808(ac, master, b0, N(root), beat * 1.4);
      bass808(ac, master, b0 + 2.5 * beat, N(root + (bar % 2 ? 3 : -2)), beat * 1.2);
      const mel = [12, 15, 12, 19, 17, 15, 12, 10];
      mel.forEach((m, i) => cowbell(ac, master, b0 + i * beat / 2, N(root + m + 24)));
    } else if (style === "tension") {
      kick(ac, master, b0, 0.6); kick(ac, master, b0 + 0.35, 0.4); // heartbeat
      kick(ac, master, b0 + 2 * beat, 0.6); kick(ac, master, b0 + 2 * beat + 0.35, 0.4);
      pad(ac, master, b0, [N(root + 12), N(root + 15), N(root + 18)], 4 * beat, 0.05);
      for (let s = 0; s < 8; s++) hat(ac, master, b0 + s * beat / 2, nb, 0.04);
    } else {
      for (let q = 0; q < 4; q++) kick(ac, master, b0 + q * beat, 0.8);
      [1, 3].forEach((q) => snare(ac, master, b0 + q * beat, nb));
      for (let s = 0; s < 8; s++) bass808(ac, master, b0 + s * beat / 2, N(root), beat / 2.2);
      pad(ac, master, b0, [N(root + 24), N(root + 27), N(root + 31)], 4 * beat, 0.07);
    }
  }
  return ac.startRendering();
}

/** Air "whoosh" on a visual cut. */
export function whoosh(ac: BaseAudioContext, out: AudioNode, t: number, level = 1) {
  const s = ac.createBufferSource(); s.buffer = noiseBuffer(ac, 0.6);
  const bp = ac.createBiquadFilter(); bp.type = "bandpass"; bp.Q.value = 1.2;
  bp.frequency.setValueAtTime(400, t);
  bp.frequency.exponentialRampToValueAtTime(4000, t + 0.25);
  bp.frequency.exponentialRampToValueAtTime(800, t + 0.45);
  const g = ac.createGain();
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(0.35 * level, t + 0.18);
  g.gain.exponentialRampToValueAtTime(0.0001, t + 0.5);
  s.connect(bp); bp.connect(g); g.connect(out);
  s.start(t); s.stop(t + 0.55);
}

/** Deep cinematic boom on impact words. */
export function boom(ac: BaseAudioContext, out: AudioNode, t: number, level = 1) {
  const o = ac.createOscillator();
  o.frequency.setValueAtTime(110, t);
  o.frequency.exponentialRampToValueAtTime(30, t + 0.6);
  o.connect(env(ac, out, t, 0.7 * level, 0.005, 0.9));
  o.start(t); o.stop(t + 1);
  const s = ac.createBufferSource(); s.buffer = noiseBuffer(ac, 0.4);
  const lp = ac.createBiquadFilter(); lp.type = "lowpass"; lp.frequency.value = 900;
  s.connect(lp); lp.connect(env(ac, out, t, 0.3 * level, 0.002, 0.3));
  s.start(t); s.stop(t + 0.4);
}

/** Rising tension sweep before the hook lands. */
export function riser(ac: BaseAudioContext, out: AudioNode, t: number, dur: number, level = 1) {
  const o = ac.createOscillator(); o.type = "sawtooth";
  o.frequency.setValueAtTime(120, t);
  o.frequency.exponentialRampToValueAtTime(900, t + dur);
  const lp = ac.createBiquadFilter(); lp.type = "lowpass";
  lp.frequency.setValueAtTime(300, t); lp.frequency.exponentialRampToValueAtTime(5000, t + dur);
  const g = ac.createGain();
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(0.12 * level, t + dur);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur + 0.05);
  o.connect(lp); lp.connect(g); g.connect(out);
  o.start(t); o.stop(t + dur + 0.1);
}
