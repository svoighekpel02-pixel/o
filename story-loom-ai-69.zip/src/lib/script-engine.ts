import type { Panel, Work } from "./catalog";
import { DEFAULT_RATE, dramatize, type NarrationStyle } from "./narration";
import { applyTemplate, type ScriptTemplate } from "./templates";

export type Goal = "suscriptores" | "likes" | "viral" | "debate";
export const GOALS: { id: Goal; label: string }[] = [
  { id: "suscriptores", label: "Conseguir suscriptores" },
  { id: "likes", label: "Conseguir likes" },
  { id: "viral", label: "Gancho viral / cliffhanger" },
  { id: "debate", label: "Debate en comentarios" },
];
export type Beat = "gancho" | "conflicto" | "revelacion" | "climax" | "remate";
export const BEAT_LABEL: Record<Beat, string> = {
  gancho: "Gancho",
  conflicto: "Conflicto",
  revelacion: "Revelación",
  climax: "Clímax",
  remate: "Remate",
};

/** Each line shows two shots: panelId for the first half, panelId2 for the second half. */
export type Line = {
  id: string;
  beat: Beat;
  text: string;
  tag: string;
  panelId: string | null;
  panelId2?: string | null;
};
export type Angle = "misterio" | "accion" | "absurdo" | "venganza" | "poder";
export const ANGLE_LABEL: Record<Angle, string> = {
  misterio: "Poder secreto / misterio",
  accion: "Acción extrema",
  absurdo: "Situación absurda",
  venganza: "Venganza",
  poder: "Subida de poder",
};
const ANGLES: Angle[] = ["misterio", "accion", "absurdo", "venganza", "poder"];

export type Video = {
  id: string;
  workId?: string;
  batchId?: string;
  title: string;
  goal: Goal;
  angle?: Angle;
  lines: Line[];
  notes?: string[];
  createdAt?: number;
  stats?: {
    views?: number;
    retention?: number;
    avgSeconds?: number;
    likes?: number;
    publishedAt?: string;
    note?: string;
  };
  templateId?: string;
  templateName?: string;
  narrationStyle?: NarrationStyle;
  duration: ScriptDuration;
};

export type ScriptDuration = 15 | 45 | 90;
export const SCRIPT_DURATIONS: {
  id: ScriptDuration;
  label: string;
  targetWords: number;
  maxLines: number;
}[] = [
  { id: 15, label: "15 s · golpe rápido", targetWords: 45, maxLines: 5 },
  { id: 45, label: "45 s · historia completa", targetWords: 115, maxLines: 9 },
  { id: 90, label: "1:30 · recap profundo", targetWords: 220, maxLines: 15 },
];

export const REFERENCE_SCRIPTS: Record<ScriptDuration, string[]> = {
  15: [
    "Gancho en el primer segundo.",
    "Problema inmediato.",
    "Revelación visual.",
    "Cierre con cliffhanger.",
  ],
  45: [
    "Gancho directo.",
    "Contexto mínimo.",
    "Conflicto y escalada.",
    "Revelación.",
    "Clímax.",
    "Promesa de la siguiente parte.",
  ],
  90: [
    "Gancho directo.",
    "Contexto del mundo.",
    "Problema del protagonista.",
    "Primer giro.",
    "Escalada con ejemplos.",
    "Revelación central.",
    "Clímax.",
    "Cierre y pregunta para comentarios.",
  ],
};

/** What the system has learned from the user's notes. Applied to every new video. */
export type Prefs = {
  maxPerBeat: number; // sentences kept per story beat
  aggressiveHook: boolean;
  titleDrop: boolean;
  reusePenalty: number;
  fx: number; // 0..1.5 sound-effects level
  captionScale: number; // 0.8..1.6
  rate: number; // voice speed
  music: "phonk" | "tension" | "epica" | "ninguna";
  banned: string[]; // panel ids never to use
  rules: string[]; // human-readable list of learned notes
};
export const DEFAULT_PREFS: Prefs = {
  maxPerBeat: 2,
  aggressiveHook: false,
  titleDrop: true,
  reusePenalty: 5,
  fx: 1,
  captionScale: 1,
  rate: DEFAULT_RATE,
  music: "phonk",
  banned: [],
  rules: [],
};

/** Keyword dictionary used to tag each sentence semantically. */
export const TAG_KEYWORDS: Record<string, string[]> = {
  reaccion: [
    "burla",
    "burlan",
    "ríe",
    "rien",
    "ríen",
    "risa",
    "sorprend",
    "asombr",
    "acus",
    "todos",
    "nadie",
    "humill",
    "desprecia",
    "shock",
    "cree que",
  ],
  monstruo: [
    "monstruo",
    "bestia",
    "criatura",
    "dragón",
    "dragon",
    "demonio",
    "rey de",
    "jefe",
    "rata",
    "lobo",
    "invocación",
  ],
  poder: [
    "habilidad",
    "poder",
    "transform",
    "invoca",
    "nivel",
    "magia",
    "mágic",
    "despert",
    "sistema",
    "fuerza",
    "aura",
    "maná",
  ],
  primer_plano: [
    "susurra",
    "mira",
    "sonríe",
    "sonrie",
    "piensa",
    "ojos",
    "finge",
    "decide",
    "jura",
    "dice",
  ],
  personaje: [
    "gerente",
    "recepcionista",
    "guerrera",
    "chica",
    "maestro",
    "líder",
    "lider",
    "princesa",
    "rey ",
    "grupo",
    "aventureros",
    "hermana",
    "padre",
  ],
  lugar: [
    "gremio",
    "ciudad",
    "mazmorra",
    "academia",
    "torre",
    "reino",
    "mundo",
    "bosque",
    "castillo",
    "alcantarilla",
  ],
  accion: [
    "ataca",
    "atacar",
    "golpe",
    "derrota",
    "lucha",
    "pelea",
    "destru",
    "enfrent",
    "mata",
    "corta",
    "ordena",
  ],
  objeto: ["cristal", "espada", "tesoro", "oro", "fortuna", "arma", "objeto", "anillo", "libro"],
};

/** Second-person hooks per angle ("tú" keeps the viewer inside the story). */
const HOOKS: Record<Angle, ((p: string) => string)[]> = {
  misterio: [(p) => `¿Qué harías si ${p}?`, (p) => `Imagina que ${p}… y nadie sabe tu secreto.`],
  accion: [
    (p) => `Imagina que ${p}. Y esto es solo el principio.`,
    (p) => `En un segundo todo explota: ${p}.`,
  ],
  absurdo: [(p) => `Esto suena a broma, pero ${p}.`, (p) => `Nadie se lo creería: ${p}.`],
  venganza: [
    (p) => `Te lo quitaron todo, porque ${p}. Ahora vuelves a cobrarte.`,
    (p) => `¿Y si ${p}, y te dieran una segunda oportunidad?`,
  ],
  poder: [
    (p) => `Eres el más débil de todos, pero ${p}.`,
    (p) => `Todos te subestiman, pero ${p}.`,
  ],
};
const AGGRESSIVE_HOOKS = [
  (p: string) => `Para. Mira esto: ${p}.`,
  (p: string) => `Este es el manhwa más roto que vas a ver hoy: ${p}.`,
];

function cta(goal: Goal, work: Work) {
  const genre = work.category.toLowerCase();
  switch (goal) {
    case "suscriptores":
      return `Si quieres conocer más historias de ${genre}, suscríbete.`;
    case "likes":
      return "Si quieres la segunda parte, deja tu like y te la traigo.";
    case "viral":
      return "Pero lo que está a punto de descubrir lo cambiará todo… y eso te lo cuento en la próxima parte.";
    case "debate":
      return `¿Tú habrías hecho lo mismo que ${work.protagonist || "él"}? Te leo en los comentarios.`;
  }
}

export function splitSentences(text: string) {
  return (text.match(/[^.!?]+[.!?]+|[^.!?]+$/g) ?? [])
    .map((s) => s.trim())
    .filter((s) => s.length > 2);
}

const decode = (s: string) =>
  s
    .replace(/&hellip;/g, "…")
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/\s+/g, " ");
function lowerFirst(s: string) {
  return s.charAt(0).toLowerCase() + s.slice(1);
}
function stripEnd(s: string) {
  return s.trim().replace(/[.!?…]+$/, "");
}
function norm(s: string) {
  return s
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
}

export function inferTag(sentence: string): string {
  const t = norm(sentence);
  let best = "escena";
  let score = 0;
  for (const [tag, words] of Object.entries(TAG_KEYWORDS)) {
    const s = words.reduce((acc, w) => acc + (t.includes(norm(w)) ? 1 : 0), 0);
    if (s > score) {
      score = s;
      best = tag;
    }
  }
  return best;
}

export function keywordSet(): Set<string> {
  return new Set(Object.values(TAG_KEYWORDS).flat().map(norm));
}

/** Copyright banners, warnings and logos that Webtoon puts at the start/end of a chapter. */
export function isJunkPanel(p: Panel) {
  return /warning|notice|copyright|banner|logo/i.test(p.path);
}

/** Scores each panel for a sentence: semantic tag, description words, narrative position, reuse penalty. */
export function matchPanels(
  lines: Omit<Line, "panelId">[],
  panels: Panel[],
  prefs: Prefs = DEFAULT_PREFS,
  variant = 0,
  shared?: Map<string, number>,
): Line[] {
  const used = new Map<string, number>();
  const prior = new Map(shared ?? []); // scenes used by earlier videos of the same batch
  const n = lines.length;
  const sorted = [...panels]
    .filter((p) => !isJunkPanel(p) && !prefs.banned.includes(p.id))
    .sort((a, b) => a.position - b.position);
  const total = Math.max(sorted.length - 1, 1);
  return lines.map((line, i) => {
    if (sorted.length === 0) return { ...line, panelId: null, panelId2: null };
    const words = norm(line.text)
      .split(/\W+/)
      .filter((w) => w.length > 3);
    const base = n > 1 ? i / (n - 1) : 0;
    // The hook opens on a strong mid/late-chapter shot, never the slow first pages; other videos shift the window.
    const progress =
      line.beat === "gancho"
        ? Math.min(0.95, 0.6 + 0.08 * variant)
        : Math.min(1, base * 0.85 + 0.15 + ((variant * 0.13) % 0.3) * (1 - base));
    const scored = sorted.map((p, idx) => {
      let s = 0;
      if (
        line.beat === "gancho" &&
        idx / total < 0.25 &&
        !(p.tag === line.tag && p.tag !== "escena")
      )
        s -= 20;
      s -= 3 * (prior.get(p.id) ?? 0);
      if (p.tag === line.tag && p.tag !== "escena") s += 6;
      const desc = norm(p.description);
      for (const w of words) if (desc.includes(w)) s += 3;
      s += 4 * (1 - Math.abs(progress - idx / total)); // follow story order
      s -= prefs.reusePenalty * (used.get(p.id) ?? 0);
      return { p, s };
    });
    scored.sort((a, b) => b.s - a.s);
    const a = scored[0]?.p;
    if (!a) return { ...line, panelId: null, panelId2: null };
    const b = scored.find((x) => x.p.id !== a.id)?.p ?? a;
    used.set(a.id, (used.get(a.id) ?? 0) + 1);
    if (b.id !== a.id) used.set(b.id, (used.get(b.id) ?? 0) + 0.5);
    if (shared) for (const id of [a.id, b.id]) shared.set(id, (shared.get(id) ?? 0) + 1);
    return { ...line, panelId: a.id, panelId2: b.id };
  });
}

let counter = 0;
export const uid = () => `${Date.now().toString(36)}-${(counter++).toString(36)}`;

/** Builds exactly ONE video for a given angle. */
export type GenerationOptions = {
  template?: ScriptTemplate;
  narrationStyle?: NarrationStyle;
  sharedUse?: Map<string, number>;
  duration?: ScriptDuration;
};
export function generateVideo(
  work: Work,
  panels: Panel[],
  goal: Goal,
  v: number,
  prefs: Prefs = DEFAULT_PREFS,
  batchId = uid(),
  options: GenerationOptions = {},
): Video {
  const angle = ANGLES[((v % ANGLES.length) + ANGLES.length) % ANGLES.length] ?? "misterio";
  const premise = stripEnd(
    decode(
      work.premise ||
        work.synopsis.split(/[.!?]/)[0] ||
        "despiertas en un mundo lleno de monstruos",
    ),
  );
  const raw: Omit<Line, "panelId">[] = [];
  const style = options.narrationStyle ?? "epico";
  const duration = options.duration ?? 15;
  const push = (beat: Beat, text: string) => {
    const formatted = dramatize(text, beat, style);
    raw.push({ id: uid(), beat, text: formatted, tag: inferTag(formatted) });
  };
  const hooks = prefs.aggressiveHook ? AGGRESSIVE_HOOKS : HOOKS[angle];
  const hook = hooks[Math.floor(v / ANGLES.length) % hooks.length] ?? hooks[0];
  if (options.template) {
    for (const line of applyTemplate(options.template, work)) {
      // Keep each request within TTS's text limit, preserving the template's beat.
      for (const sentence of splitSentences(line.text)) push(line.beat, sentence);
    }
  } else {
    if (hook) push("gancho", hook(lowerFirst(premise)));
    const sections: [Beat, string][] = [
      ["conflicto", work.conflict],
      ["revelacion", work.reveal],
      ["climax", work.climax],
      ["remate", work.twist],
    ];
    // Different angles emphasise different beats.
    const order: Beat[] =
      angle === "accion"
        ? ["climax", "conflicto", "revelacion", "remate"]
        : ["conflicto", "revelacion", "climax", "remate"];
    for (const beat of order) {
      const text = decode(sections.find((s) => s[0] === beat)?.[1] ?? "");
      let sents = splitSentences(text);
      if (beat === "revelacion" && sents[0] && !/^pero/i.test(sents[0]))
        sents[0] = `Pero ${lowerFirst(sents[0])}`;
      sents = sents.slice(0, Math.max(1, prefs.maxPerBeat));
      sents.forEach((s) => push(beat, s));
    }
    if (raw.length === 1 && work.synopsis)
      splitSentences(decode(work.synopsis))
        .slice(0, 4)
        .forEach((s) => push("conflicto", s));
  }
  // Deterministic duration profiles: no external model decides pacing or wording.
  const CAP: Record<string, number> = {
    gancho: 12,
    conflicto: 18,
    revelacion: 18,
    climax: 15,
    remate: 10,
  };
  const profile = SCRIPT_DURATIONS.find((item) => item.id === duration) ?? SCRIPT_DURATIONS[0]!;
  const seen = new Set<string>();
  const candidates =
    duration === 15
      ? raw.filter((l) =>
          l.beat === "remate" || seen.has(l.beat) ? false : (seen.add(l.beat), true),
        )
      : raw;
  const tight = candidates.map((l) => {
    const w = l.text.split(/\s+/);
    return w.length <= (CAP[l.beat] ?? 15)
      ? l
      : {
          ...l,
          text:
            w
              .slice(0, CAP[l.beat] ?? 15)
              .join(" ")
              .replace(/[,;:]$/, "") + "…",
        };
  });
  raw.length = 0;
  raw.push(...tight.slice(0, profile.maxLines - 1));
  push("remate", `Así comienza ${work.title}.`);
  while (raw.length > profile.maxLines) raw.splice(raw.length - 2, 1);
  const words = raw.reduce((total, line) => total + line.text.split(/\s+/).length, 0);
  if (words > profile.targetWords) {
    let remaining = profile.targetWords;
    for (const line of raw) {
      const tokens = line.text.split(/\s+/);
      const keep = Math.max(4, Math.min(tokens.length, remaining));
      line.text =
        tokens
          .slice(0, keep)
          .join(" ")
          .replace(/[,;:]$/, "") + (keep < tokens.length ? "…" : "");
      remaining -= keep;
    }
  }
  void cta;
  void goal;
  return {
    id: uid(),
    workId: work.id,
    batchId,
    title: `${work.title} · Video ${v + 1}`,
    goal,
    angle,
    ...(options.template
      ? { templateId: options.template.id, templateName: options.template.name }
      : {}),
    narrationStyle: style,
    duration,
    lines: matchPanels(raw, panels, prefs, v, options.sharedUse),
    notes: [],
    createdAt: Date.now(),
  };
}

/** Returns exactly `count` videos, each with a different angle. */
export function generateBatch(
  work: Work,
  panels: Panel[],
  count: number,
  goal: Goal,
  prefs: Prefs = DEFAULT_PREFS,
  options: GenerationOptions = {},
): Video[] {
  const batchId = uid();
  const sharedUse = new Map<string, number>(); // each video in the batch prefers scenes the others didn't use
  return Array.from({ length: Math.max(0, Math.floor(count)) }, (_, v) =>
    generateVideo(work, panels, goal, v, prefs, batchId, { ...options, sharedUse }),
  );
}

/** Turns a free-text note ("muy lento", "quitar viñeta 3", "más FX") into lasting preferences. */
export function learnFromNote(note: string, prefs: Prefs, video?: Video): Prefs {
  const t = norm(note);
  const p: Prefs = { ...prefs, banned: [...prefs.banned], rules: [...prefs.rules] };
  if (/lent|rapid|ritmo|aburr|largo/.test(t)) {
    p.maxPerBeat = Math.max(1, p.maxPerBeat - 1);
    p.rate = Math.min(1.5, +(p.rate + 0.08).toFixed(2));
  }
  if (/corto|mas historia|mas contexto/.test(t)) p.maxPerBeat = Math.min(4, p.maxPerBeat + 1);
  if (/gancho|inicio|principio|engancha/.test(t)) p.aggressiveHook = true;
  if (/fx|efecto|sonido|golpe|whoosh/.test(t))
    p.fx = Math.min(1.5, p.fx + (/menos|quita|sin/.test(t) ? -0.4 : 0.3));
  if (/phonk/.test(t)) p.music = "phonk";
  else if (/tension|suspens/.test(t)) p.music = "tension";
  else if (/epic/.test(t)) p.music = "epica";
  else if (/sin musica|quita.*musica/.test(t)) p.music = "ninguna";
  if (/subtitul|letra|texto/.test(t))
    p.captionScale = Math.min(
      1.6,
      Math.max(0.8, p.captionScale + (/pequen|menos/.test(t) ? -0.15 : 0.15)),
    );
  if (/repit|repet/.test(t)) p.reusePenalty += 4;
  if (/titulo|nombre/.test(t) && /quita|sin/.test(t)) p.titleDrop = false;
  if (video && /vinet|imagen|escena|frase/.test(t) && /quit|mal|fuera|borra|no pega/.test(t)) {
    for (const m of t.matchAll(/(\d+)/g)) {
      const line = video.lines[Number(m[1]) - 1];
      for (const id of [line?.panelId, line?.panelId2])
        if (id && !p.banned.includes(id)) p.banned.push(id);
    }
  }
  if (note.trim()) p.rules.push(note.trim());
  return p;
}
