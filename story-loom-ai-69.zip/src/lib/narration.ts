export type NarrationStyle = "accion" | "epico" | "misterio";
export const DEFAULT_VOICE = "es-MX-JorgeNeural";
export const DEFAULT_RATE = 1.10;
export const NARRATION_STYLES: { id: NarrationStyle; label: string; rate: number; pitch: number }[] = [
  { id: "accion", label: "Acción rápida", rate: 1.20, pitch: 4 },
  { id: "epico", label: "Narrador épico", rate: 1.10, pitch: -3 },
  { id: "misterio", label: "Misterio", rate: 1.00, pitch: -5 },
];

export function narrationProsody(style: NarrationStyle, beat: string) {
  const preset = NARRATION_STYLES.find((s) => s.id === style) ?? NARRATION_STYLES[1];
  const pitch = preset?.pitch ?? -3;
  return { pitch: pitch + (beat === "climax" ? 3 : beat === "revelacion" ? 2 : 0) };
}

/** Punctuation is spoken by the neural voice; never inject unsupported SSML styles. */
export function dramatize(text: string, beat: string, style: NarrationStyle): string {
  const trimmed = text.trim();
  if (!trimmed) return "";
  const body = trimmed.replace(/[.!…]+$/, "");
  if (beat === "climax") return style === "misterio" ? `${body}…` : `¡${body.replace(/^¡/, "").replace(/!$/, "")}!`;
  if (beat === "revelacion") return body.replace(/^Pero\s+/i, "Pero… ") + "…";
  if (beat === "gancho" && !/[?¿!¡]/.test(trimmed)) return `${body}…`;
  return trimmed;
}

export function validateTtsInput(d: { text: string; voice: string; rate: number; pitch?: number }, voices: readonly { id: string }[]) {
  if (typeof d.text !== "string" || !d.text.trim() || d.text.length > 1000) throw new Error("Texto inválido");
  if (!voices.some((v) => v.id === d.voice)) throw new Error("Voz inválida");
  if (!Number.isFinite(d.rate) || (d.pitch !== undefined && !Number.isFinite(d.pitch))) throw new Error("Ritmo o tono inválido");
  return { text: d.text, voice: d.voice, rate: Math.max(-50, Math.min(100, Math.round(d.rate))), pitch: Math.max(-20, Math.min(20, Math.round(d.pitch ?? 0))) };
}