import { createServerFn } from "@tanstack/react-start";
import { validateTtsInput } from "./narration";

/** Jorge is the only voice: no female or robotic fallback. */
export const VOICES = [{ id: "es-MX-JorgeNeural", label: "Jorge (México)" }] as const;

export const ttsLine = createServerFn({ method: "POST" })
  .inputValidator((d: { text: string; voice: string; rate: number; pitch?: number }) => validateTtsInput({ ...d, voice: "es-MX-JorgeNeural" }, VOICES))
  .handler(async ({ data }) => {
    const { synthesize } = await import("./edge-tts");
    let r;
    try {
      r = await synthesize(data.text, data.voice, data.rate, data.pitch);
    } catch {
      r = await synthesize(data.text, data.voice, data.rate, data.pitch); // one retry, still Jorge
    }
    let bin = "";
    for (let i = 0; i < r.audio.length; i += 0x8000) bin += String.fromCharCode(...r.audio.subarray(i, i + 0x8000));
    return { audio: btoa(bin), words: r.words };
  });
