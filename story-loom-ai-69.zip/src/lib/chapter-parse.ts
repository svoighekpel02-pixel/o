export const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0 Safari/537.36";

export function attr(tag: string, name: string) {
  const r = new RegExp(`\\s${name}=["']([^"']+)["']`, "i");
  return tag.match(r)?.[1] ?? "";
}

export function decode(s: string) {
  return s
    .replace(/&amp;/g, "&")
    .replace(/&#39;/g, "'")
    .replace(/&quot;/g, '"')
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&([a-z])(acute|tilde|uml|grave|circ);/gi, (_, c: string, k: string) => {
      const map: Record<string, string> = { acute: "\u0301", tilde: "\u0303", uml: "\u0308", grave: "\u0300", circ: "\u0302" };
      return (c + map[k.toLowerCase()]).normalize("NFC");
    })
    .replace(/&iexcl;/g, "¡")
    .replace(/&iquest;/g, "¿");
}

/** Returns panel image URLs (reading order) found in a chapter page. */
export function parseChapterImages(html: string, baseUrl: string): string[] {
  const base = new URL(baseUrl);
  let scope = html;
  const viewer = html.match(/<div[^>]+(?:id=["']_imageList["']|class=["'][^"']*(?:viewer_img|reading-content|chapter-content|container-chapter-reader)[^"']*["'])[\s\S]*?<\/div>\s*<\/div>/i);
  if (viewer && (viewer[0].match(/<img/gi)?.length ?? 0) >= 3) scope = viewer[0];
  const seen = new Set<string>();
  const images: string[] = [];
  const imgRe = /<img\b[^>]*>/gi;
  let m: RegExpExecArray | null;
  while ((m = imgRe.exec(scope))) {
    const tag = m[0];
    const src = attr(tag, "data-url") || attr(tag, "data-src") || attr(tag, "data-lazy-src") || attr(tag, "data-original") || attr(tag, "src");
    if (!src || src.startsWith("data:")) continue;
    let abs: string;
    try {
      abs = new URL(src.trim(), base).toString();
    } catch {
      continue;
    }
    if (/(logo|icon|avatar|banner|sprite|emoji|thumb|ads?[/_-]|\.gif|\.svg)/i.test(abs)) continue;
    const w = Number(attr(tag, "width") || 0);
    if (w && w < 300) continue;
    if (seen.has(abs)) continue;
    seen.add(abs);
    images.push(abs);
  }
  return images.slice(0, 120);
}
