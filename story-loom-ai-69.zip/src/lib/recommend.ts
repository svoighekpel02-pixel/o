/** Trope keywords detected in a title (plus the webtoons sub-genre). */
export const TROPES: Record<string, string[]> = {
  regreso: ["regres", "renac", "reencarn", "vuelve", "segunda vida"],
  asesino: ["asesin", "mercenari", "muerte", "villano", "matar"],
  mazmorra: ["mazmorra", "torre", "dungeon", "portal"],
  cazador: ["cazador", "hunter", "clase s", "rango"],
  chetado: ["omnipotente", "absoluto", "rey", "dios", "nivel", "multiclase", "supremo", "devorador", "glot"],
  clan: ["clan", "familia", "conde", "señor", "duque", "bastardo", "noble"],
  artes_marciales: ["espada", "murim", "marcial", "guerrero", "puño"],
};

const norm = (s: string) => s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");

export function tropesOf(item: { title: string; subgenre?: string }): string[] {
  const t = norm(item.title);
  const found = Object.entries(TROPES)
    .filter(([, ws]) => ws.some((w) => t.includes(norm(w))))
    .map(([k]) => k);
  if (item.subgenre) found.push(`genero:${item.subgenre}`);
  return found;
}

/** Ranks unliked items by how many tropes they share with liked ones. */
export function recommend<T extends { titleNo: string; title: string; subgenre?: string }>(items: T[], liked: string[], limit = 15): T[] {
  const likedSet = new Set(liked);
  const weights = new Map<string, number>();
  for (const it of items) if (likedSet.has(it.titleNo)) for (const t of tropesOf(it)) weights.set(t, (weights.get(t) ?? 0) + 1);
  if (weights.size === 0) return [];
  return items
    .filter((it) => !likedSet.has(it.titleNo))
    .map((it) => ({ it, s: tropesOf(it).reduce((a, t) => a + (weights.get(t) ?? 0) * (t.startsWith("genero:") ? 1 : 2), 0) }))
    .filter((x) => x.s > 0)
    .sort((a, b) => b.s - a.s)
    .slice(0, limit)
    .map((x) => x.it);
}

/** Turns a synopsis into story beats for the script engine. */
export function beatsFromSynopsis(synopsis: string) {
  const s = (synopsis.match(/[^.!?]+[.!?]+|[^.!?]+$/g) ?? []).map((x) => x.trim()).filter(Boolean);
  const premise = (s[0] ?? "").replace(/[.!?]+$/, "");
  return {
    premise,
    conflict: s[1] ?? s[0] ?? "",
    reveal: s[2] ?? "",
    climax: s.slice(3, -1).join(" "),
    twist: s.length > 3 ? (s[s.length - 1] ?? "") : "",
  };
}
