export type MediaLicense = {
  id: string;
  kind: "music" | "sfx" | "meme";
  title: string;
  style?: string;
  season?: string;
  author: string;
  sourceUrl: string;
  downloadedAt: string | null;
  license: string;
  commercialUse: "verified" | "pending" | "not_allowed";
  localPath: string | null;
};

/** Only verified assets may be enabled in the editor. Pending entries are intentionally excluded. */
export const MEDIA_MANIFEST: MediaLicense[] = [
  {
    id: "pixabay-funk-pending",
    kind: "music",
    title: "Funk track — pendiente de selección y descarga",
    style: "funk",
    author: "Pendiente de verificar",
    sourceUrl: "https://pixabay.com/music/",
    downloadedAt: null,
    license: "Pixabay Content License — no se activa hasta verificar la pista concreta",
    commercialUse: "pending",
    localPath: null,
  },
];

export function enabledMedia(kind?: MediaLicense["kind"]) {
  return MEDIA_MANIFEST.filter(
    (item) => item.commercialUse === "verified" && (!kind || item.kind === kind),
  );
}
