import WebSocket from "ws";
// Free Microsoft Edge "Read Aloud" neural TTS (same service the edge-tts tool uses). No key needed.
const TOKEN = "6A5AA1D4EAFF4E9FB37E23D68491D6F4";
const GEC_VERSION = "2-155.0.4283.45";
const HOST = "api.msedgeservices.com/tts/cognitiveservices/websocket/v1";
const WINDOWS_EPOCH = 11644473600n;
const U32 = 0xffffffff;
const PREFIX = new TextEncoder().encode("Copyright (C) Microsoft Corporation. All rights reserved.");
const COEFFICIENTS: ReadonlyArray<readonly [number, number]> = [
  [0xe82e91b1, 0xb32700d0], [0x44de24c6, 0x88dff51d],
  [0x3beb65bc, 0x29514038], [0xc89c5933, 0xb328cbdf],
  [0x8d1ec211, 0xd405b4d5], [0x314ef5d5, 0x26e55f3c],
  [0xe92491b1, 0x607801c6], [0xf0a5b9d5, 0x82b2c1fb],
  [0x06064cf3, 0xfa51a3da], [0xda79fa60, 0x207cc464],
  [0xbed20560, 0x3c3c74f3], [0x89f9c9f8, 0xd2d14b61],
  [0x35fa38c6, 0xbb04a2c1], [0xcb49e3c6, 0xc5626167],
];
const mul = Math.imul;
const rol16 = (x: number) => ((x << 16) | (x >>> 16)) >>> 0;

function cs64Digest(data: Uint8Array, sha: Uint8Array): Uint8Array {
  const view = new DataView(sha.buffer, sha.byteOffset, sha.byteLength);
  const keyA = (view.getUint32(0, true) | 1) >>> 0;
  const keyB = (view.getUint32(4, true) | 1) >>> 0;
  const factors = [mul(keyA, 0x82893933) >>> 0, mul(keyB, 0x82893933) >>> 0];
  const terms = COEFFICIENTS.map(([c], i) => mul(c, factors[i % 2]) >>> 0);
  const offsets = COEFFICIENTS.map(([, o]) => o);
  const padded = new Uint8Array(Math.ceil((data.length + 1) / 8) * 8);
  padded.set(data, 1);
  const words = new DataView(padded.buffer);
  for (let i = 0; i < padded.length / 4; i++) {
    const word = words.getUint32(i * 4, true);
    let term = mul(word, i % 2 === 0 ? keyA : keyB);
    let offset = mul(rol16(word), i % 2 === 0 ? 0xef0569fb : 0xc31713db);
    if (i === 0) {
      term = (term + mul(0xf2f90b1a, factors[0])) >>> 0;
      offset = (offset + 0x0b1a0000) >>> 0;
    }
    terms.push(term >>> 0);
    offsets.push(offset >>> 0);
  }
  let swapAcc = 0, swapLast = 0, state = 0, acc = 0;
  for (let i = 0; i < terms.length; i += 2) {
    const x = terms[i], y = terms[i + 1];
    let t = rol16((offsets[i] + x) >>> 0);
    let q = mul(t, 0x76f50f34);
    swapAcc += (mul(rol16(q), 0xc3efea97) + q) >>> 0;
    t = rol16((offsets[i + 1] + y) >>> 0);
    q = mul(t, 0x1881ce3c);
    swapLast = (mul(rol16(q), 0x35bd1ec9) + q) >>> 0;
    swapAcc = (swapAcc + swapLast) >>> 0;
    state = (mul(state, keyA) + x) >>> 0;
    for (const k of [0xcf98b111, 0x87085b9f, 0x12ceb96d, 0x257e1d83]) state = mul(rol16(state), k) >>> 0;
    acc = (acc + state) >>> 0;
    t = (mul(state, keyB) + y) >>> 0;
    t = mul(rol16(t), 0xa27416f5) >>> 0;
    t = mul(rol16(t), 0xd38396ff) >>> 0;
    state = mul(rol16(mul(rol16(t), 0x7c932b89)), 0xbfa49f69) >>> 0;
    acc = (acc + state) >>> 0;
  }
  const result = new Uint8Array(8);
  const out = new DataView(result.buffer);
  out.setUint32(0, (swapLast ^ state) >>> 0, true);
  out.setUint32(4, (swapAcc ^ acc) >>> 0, true);
  return result;
}

async function secMsGec() {
  const epochSeconds = BigInt(Math.floor(Date.now() / 1000)) + WINDOWS_EPOCH;
  const ticks = (epochSeconds - (epochSeconds % 300n)) * 10000000n;
  const data = new TextEncoder().encode(`${ticks}${TOKEN}`);
  const hashInput = new Uint8Array(PREFIX.length + data.length);
  hashInput.set(PREFIX);
  hashInput.set(data, PREFIX.length);
  const sha = new Uint8Array(await crypto.subtle.digest("SHA-256", hashInput));
  const cs64 = cs64Digest(data, sha);
  const hex = (bytes: Uint8Array) => [...bytes].map((b) => b.toString(16).padStart(2, "0")).join("").toUpperCase();
  return `${hex(cs64)}-${hex(sha)}`;
}

export type WordMark = { offset: number; duration: number; text: string }; // seconds
export type TtsResult = { audio: Uint8Array; words: WordMark[] };

const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/'/g, "&apos;").replace(/"/g, "&quot;");
// Edge TTS requires canonical UUIDs for ConnectionId and X-RequestId.
const uid = () => crypto.randomUUID();

type Sock = { send(d: string): void; close(): void; addEventListener(t: string, f: (e: any) => void): void };

async function open(url: string): Promise<Sock> {
  const headers = {
    Upgrade: "websocket",
    Pragma: "no-cache",
    "Cache-Control": "no-cache",
    "Accept-Language": "en-US,en;q=0.9",
    Cookie: `MUID=${uid().toUpperCase()};`,
    Origin: "chrome-extension://jdiccldimpdaibmpdkjnbmckianbfold",
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0",
  };
  if (typeof (globalThis as any).WebSocketPair !== "undefined") {
    const res = await fetch(url.replace("wss://", "https://"), { headers });
    const ws = (res as any).webSocket;
    if (!ws) throw new Error(`TTS conexión rechazada (${res.status})`);
    ws.accept();
    return ws;
  }
  const ws = new WebSocket(url, {
    headers: { Origin: headers.Origin, "User-Agent": headers["User-Agent"], Cookie: headers.Cookie, Pragma: "no-cache", "Cache-Control": "no-cache" },
  }) as unknown as WebSocket;
  ws.binaryType = "arraybuffer";
  await new Promise<void>((ok, ko) => {
    ws.addEventListener("open", () => ok());
    ws.addEventListener("error", () => ko(new Error("TTS conexión fallida")));
  });
  return ws as unknown as Sock;
}

export async function synthesize(text: string, voice = "es-US-AlonsoNeural", ratePct = 10, pitchHz = 0): Promise<TtsResult> {
  const url = `wss://${HOST}?Ocp-Apim-Subscription-Key=${TOKEN}&Sec-MS-GEC=${await secMsGec()}&Sec-MS-GEC-Version=${GEC_VERSION}&ConnectionId=${uid()}`;
  const ws = await open(url);
  const ts = new Date().toString();
  const chunks: Uint8Array[] = [];
  const words: WordMark[] = [];
  const done = new Promise<void>((ok, ko) => {
    const timer = setTimeout(() => ko(new Error("TTS tiempo agotado")), 30000);
    ws.addEventListener("message", async (e: any) => {
      const d = e.data;
      if (typeof d === "string") {
        const sep = d.indexOf("\r\n\r\n");
        const head = d.slice(0, sep);
        if (head.includes("Path:turn.end")) { clearTimeout(timer); ok(); }
        else if (head.includes("Path:audio.metadata")) {
          let j: { Metadata?: Array<{ Type?: string; Data?: { Offset?: number; Duration?: number; text?: { Text?: string } } }> };
          try { j = JSON.parse(d.slice(sep + 4)); } catch { return; }
          for (const m of j.Metadata ?? []) if (m.Type === "WordBoundary")
            words.push({ offset: (m.Data?.Offset ?? 0) / 1e7, duration: (m.Data?.Duration ?? 0) / 1e7, text: m.Data?.text?.Text ?? "" });
        }
        return;
      }
      const buf = new Uint8Array(d instanceof ArrayBuffer ? d : await (d as Blob).arrayBuffer());
      const first = buf[0], second = buf[1];
      if (first === undefined || second === undefined) return;
      const hl = (first << 8) | second;
      const head = new TextDecoder().decode(buf.slice(2, 2 + hl));
      if (head.includes("Path:audio")) chunks.push(buf.slice(2 + hl));
    });
    ws.addEventListener("close", () => { clearTimeout(timer); ok(); });
    ws.addEventListener("error", () => { clearTimeout(timer); ko(new Error("TTS error")); });
  });
  ws.send(`X-Timestamp:${ts}\r\nContent-Type:application/json; charset=utf-8\r\nPath:speech.config\r\n\r\n{"context":{"synthesis":{"audio":{"metadataoptions":{"sentenceBoundaryEnabled":"false","wordBoundaryEnabled":"true"},"outputFormat":"audio-24khz-48kbitrate-mono-mp3"}}}}`);
  const r = ratePct >= 0 ? `+${ratePct}%` : `${ratePct}%`;
  const pitch = `${pitchHz >= 0 ? "+" : ""}${pitchHz}Hz`;
  const language = voice.split("-").slice(0, 2).join("-");
  ws.send(`X-RequestId:${uid()}\r\nContent-Type:application/ssml+xml\r\nX-Timestamp:${ts}Z\r\nPath:ssml\r\n\r\n<speak version='1.0' xmlns='http://www.w3.org/2001/10/synthesis' xml:lang='${language}'><voice name='${voice}'><prosody pitch='${pitch}' rate='${r}' volume='+0%'>${esc(text)}</prosody></voice></speak>`);
  await done;
  try { ws.close(); } catch {}
  const len = chunks.reduce((a, c) => a + c.length, 0);
  if (!len) throw new Error("TTS sin audio");
  const audio = new Uint8Array(len);
  let o = 0;
  for (const c of chunks) { audio.set(c, o); o += c.length; }
  return { audio, words };
}
