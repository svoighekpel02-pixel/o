import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { attr, decode, parseChapterImages, UA } from "./chapter-parse";

export type WebtoonItem = {
  titleNo: string;
  title: string;
  author: string;
  cover: string;
  url: string;
  subgenre: string;
  isNew: boolean;
  likes: string;
};

const headers = { "User-Agent": UA, Accept: "text/html", "Accept-Language": "es-ES,es;q=0.9" };

/** Lists the Action genre of webtoons.com (Spanish edition). */
export const listActionWebtoons = createServerFn({ method: "GET" }).handler(async () => {
  try {
    const res = await fetch("https://www.webtoons.com/es/genres/action", { headers });
    if (!res.ok) return { items: [] as WebtoonItem[], error: `webtoons.com respondió ${res.status}` };
    const html = await res.text();
    const items: WebtoonItem[] = [];
    const seen = new Set<string>();
    const re = /<a\s+href="(https:\/\/www\.webtoons\.com\/es\/([a-z-]+)\/[^"]+\/list\?title_no=(\d+))"[\s\S]*?<\/a>/g;
    let m: RegExpExecArray | null;
    while ((m = re.exec(html))) {
      const block = m[0];
      const [, url = "", subgenre = "", titleNo = ""] = m;
      if (seen.has(titleNo)) continue;
      const title = block.match(/class="title">([^<]+)</)?.[1];
      const imgTag = block.match(/<img\b[^>]*>/)?.[0] ?? "";
      if (!title || !imgTag) continue;
      seen.add(titleNo);
      items.push({
        titleNo,
        url,
        subgenre,
        title: decode(title).trim(),
        author: decode(block.match(/class="author">([^<]+)</)?.[1] ?? "").trim(),
        cover: attr(imgTag, "src"),
        isNew: /badge_new/.test(block),
        likes: block.match(/view_count[^>]*>([^<]+)</)?.[1]?.trim() ?? "",
      });
    }
    return { items, error: "" };
  } catch {
    return { items: [] as WebtoonItem[], error: "No se pudo conectar con webtoons.com" };
  }
});

/** Opens a webtoon's page, finds episode 1 and extracts its real panels. */
export const importWebtoon = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => z.object({ url: z.string().url().startsWith("https://www.webtoons.com/") }).parse(input))
  .handler(async ({ data }) => {
    const fail = (error: string) => ({ ok: false as const, error, title: "", synopsis: "", cover: "", images: [] as string[] });
    const res = await fetch(data.url, { headers });
    if (!res.ok) return fail(`webtoons.com respondió ${res.status}`);
    const html = await res.text();
    const meta = (p: string) => decode(html.match(new RegExp(`<meta[^>]+property=["']${p}["'][^>]+content=["']([^"']+)`, "i"))?.[1] ?? "").trim();
    const viewer = html.match(/href="(https:\/\/www\.webtoons\.com\/[^"]+\/viewer\?title_no=\d+&(?:amp;)?episode_no=)\d+"/);
    if (!viewer) return fail("No encontré capítulos en esa obra.");
    const epUrl = `${(viewer[1] ?? "").replace("&amp;", "&")}1`;
    const ep = await fetch(epUrl, { headers: { ...headers, Referer: data.url } });
    if (!ep.ok) return fail(`El capítulo 1 respondió ${ep.status}`);
    const images = parseChapterImages(await ep.text(), ep.url || epUrl);
    if (images.length === 0) return fail("No encontré viñetas en el capítulo 1.");
    return { ok: true as const, error: "", title: meta("og:title"), synopsis: meta("og:description"), cover: meta("og:image") || images[0], images };
  });

export type Episode = { no: number; title: string; date: number; link: string };
/** Chapter list with real release dates (Webtoon mobile API, no key). */
export const webtoonEpisodes = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => z.object({ url: z.string().url() }).parse(input))
  .handler(async ({ data }) => {
    const no = data.url.match(/title_no=(\d+)/)?.[1];
    if (!no) return { episodes: [] as Episode[], error: "Esta obra no tiene enlace de Webtoon." };
    try {
      const res = await fetch(`https://m.webtoons.com/api/v1/webtoon/${no}/episodes?pageSize=1000`, { headers: { "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X)" } });
      if (!res.ok) return { episodes: [] as Episode[], error: `webtoons.com respondió ${res.status}` };
      const j = (await res.json()) as { result?: { episodeList?: { episodeNo: number; episodeTitle: string; exposureDateMillis: number; viewerLink: string }[] } };
      const episodes = (j.result?.episodeList ?? []).map((e) => ({ no: e.episodeNo, title: e.episodeTitle, date: e.exposureDateMillis, link: `https://www.webtoons.com${e.viewerLink}` }));
      return { episodes, error: "" };
    } catch {
      return { episodes: [] as Episode[], error: "No se pudo conectar con webtoons.com" };
    }
  });
