import type { Work } from "./catalog";
import type { Beat } from "./script-engine";

export const TEMPLATE_BEATS: Beat[] = ["gancho", "conflicto", "revelacion", "climax", "remate"];
export type ScriptTemplate = {
  id: string;
  name: string;
  classification: "referencia" | "10k";
  reference: string;
  source: string;
  patterns: Record<Beat, string>;
};
export const DEFAULT_PATTERNS: Record<Beat, string> = {
  gancho: "Imagina que {premisa}…",
  conflicto: "{conflicto}",
  revelacion: "Pero… {revelacion}",
  climax: "¡{climax}!",
  remate: "{remate}",
};
export const PLACEHOLDERS = ["premisa", "conflicto", "revelacion", "climax", "remate", "titulo", "protagonista"] as const;
const KEY = "samumanga:templates";

export function templateErrors(template: ScriptTemplate): string[] {
  const errors: string[] = [];
  if (!template.name.trim()) errors.push("Falta el nombre.");
  if (!template.reference.trim()) errors.push("Falta el guion de referencia.");
  for (const beat of TEMPLATE_BEATS) {
    const pattern = template.patterns[beat];
    const tokens = [...pattern.matchAll(/\{([^{}]+)\}/g)].map((m) => m[1]);
    if (!tokens.some((token) => PLACEHOLDERS.some((p) => p === token))) errors.push(`Falta una variable en ${beat}.`);
    if (tokens.some((token) => !PLACEHOLDERS.some((p) => p === token))) errors.push(`Variable desconocida en ${beat}.`);
    if (pattern.length > 600) errors.push(`La estructura de ${beat} es demasiado larga.`);
  }
  return errors;
}

export function applyTemplate(template: ScriptTemplate, work: Work): { beat: Beat; text: string }[] {
  const values: Record<string, string> = {
    premisa: work.premise || work.synopsis.split(/[.!?]/)[0] || "",
    conflicto: work.conflict,
    revelacion: work.reveal,
    climax: work.climax,
    remate: work.twist,
    titulo: work.title,
    protagonista: work.protagonist || "el protagonista",
  };
  return TEMPLATE_BEATS.map((beat) => ({
    beat,
    text: template.patterns[beat].replace(/\{([^{}]+)\}/g, (_, key: string) => (values[key] ?? "").trim().replace(/[.!?…]+$/, "")),
  })).filter((line) => /[\p{L}\p{N}]/u.test(line.text));
}

export function loadTemplates(): ScriptTemplate[] {
  try {
    const parsed: unknown = JSON.parse(localStorage.getItem(KEY) || "[]");
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((t): t is ScriptTemplate => typeof t?.id === "string" && typeof t?.name === "string" && typeof t?.reference === "string" && typeof t?.source === "string" && ["referencia", "10k"].includes(t?.classification) && TEMPLATE_BEATS.every((beat) => typeof t?.patterns?.[beat] === "string"));
  } catch { return []; }
}
export function saveTemplates(templates: ScriptTemplate[]) {
  localStorage.setItem(KEY, JSON.stringify(templates));
  window.dispatchEvent(new Event("samumanga:templates-changed"));
}