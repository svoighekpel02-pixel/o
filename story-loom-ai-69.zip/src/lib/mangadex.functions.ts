import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const API = "https://api.mangadex.org";
const USER_AGENT = "StoryLoom/SamuManga (legal manga discovery; contact via repository)";
const cache = new Map<string, { expires: number; value: unknown }>();
let nextRequestAt = 0;

export type MangaDexManga = {
  id: string;
  title: string;
  synopsis: string;
  cover: string | null;
  sourceUrl: string;
};
export type MangaDexChapter = {
  id: string;
  number: string;
  title: string;
  publishedAt: string;
  pages: number;
};

function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function requestJson<T>(path: string, attempt = 0): Promise<T> {
  const now = Date.now();
  if (now < nextRequestAt) await sleep(nextRequestAt - now);
  nextRequestAt = Date.now() + 220;
  const response = await fetch(`${API}${path}`, {
    headers: { Accept: "application/json", "User-Agent": USER_AGENT },
    redirect: "follow",
  });
  if (response.status === 429 && attempt < 3) {
    const retryAfter = Number(response.headers.get("retry-after")) || 1 + attempt;
    await sleep(Math.min(8000, retryAfter * 1000));
    return requestJson<T>(path, attempt + 1);
  }
  if (!response.ok) throw new Error(`MangaDex respondió ${response.status}`);
  return response.json() as Promise<T>;
}

async function cached<T>(key: string, load: () => Promise<T>, ttl = 5 * 60_000): Promise<T> {
  const hit = cache.get(key);
  if (hit && hit.expires > Date.now()) return hit.value as T;
  const value = await load();
  cache.set(key, { expires: Date.now() + ttl, value });
  return value;
}

function textValue(value: unknown): string {
  if (!value || typeof value !== "object") return "";
  const record = value as Record<string, unknown>;
  return typeof record.es === "string"
    ? record.es
    : typeof record["es-la"] === "string"
      ? record["es-la"]
      : ((Object.values(record).find((item) => typeof item === "string") as string) ?? "");
}

export function parseMangaDexMangaList(payload: unknown): MangaDexManga[] {
  const data = (payload as { data?: unknown[] })?.data ?? [];
  return data.flatMap((entry) => {
    if (!entry || typeof entry !== "object") return [];
    const item = entry as {
      id?: string;
      attributes?: { title?: unknown; description?: unknown; links?: Record<string, unknown> };
      relationships?: unknown[];
    };
    if (!item.id) return [];
    const relationships = Array.isArray(item.relationships) ? item.relationships : [];
    const cover = relationships.find(
      (rel) => rel && typeof rel === "object" && (rel as { type?: string }).type === "cover_art",
    ) as { attributes?: { fileName?: string } } | undefined;
    const title = textValue(item.attributes?.title) || "Manga sin título";
    const coverUrl = cover?.attributes?.fileName
      ? `https://uploads.mangadex.org/covers/${item.id}/${cover.attributes.fileName}`
      : null;
    return [
      {
        id: item.id,
        title,
        synopsis: textValue(item.attributes?.description),
        cover: coverUrl,
        sourceUrl: `https://mangadex.org/title/${item.id}`,
      },
    ];
  });
}

export function parseMangaDexChapters(payload: unknown): MangaDexChapter[] {
  const data = (payload as { data?: unknown[] })?.data ?? [];
  return data.flatMap((entry) => {
    if (!entry || typeof entry !== "object") return [];
    const item = entry as {
      id?: string;
      attributes?: {
        chapter?: string | null;
        title?: string | null;
        publishedAt?: string;
        pages?: number;
      };
    };
    if (!item.id) return [];
    return [
      {
        id: item.id,
        number: item.attributes?.chapter ?? "",
        title: item.attributes?.title ?? "",
        publishedAt: item.attributes?.publishedAt ?? "",
        pages: item.attributes?.pages ?? 0,
      },
    ];
  });
}

export function mangaDexImageUrls(baseUrl: string, chapter: { hash: string; data: string[] }) {
  return chapter.data.map((file) => `${baseUrl}/data/${chapter.hash}/${file}`);
}

export const searchMangaDex = createServerFn({ method: "GET" })
  .inputValidator((input: unknown) =>
    z
      .object({
        query: z.string().trim().min(2).max(120),
        limit: z.number().int().min(1).max(20).optional(),
      })
      .parse(input),
  )
  .handler(async ({ data }) => {
    try {
      const params = new URLSearchParams({
        title: data.query,
        limit: String(data.limit ?? 12),
        "order[relevance]": "desc",
        "contentRating[]": "safe",
        "includes[]": "cover_art",
      });
      params.append("availableTranslatedLanguage[]", "es");
      params.append("availableTranslatedLanguage[]", "es-la");
      const payload = await cached(`search:${params}`, () => requestJson(`/manga?${params}`));
      return { items: parseMangaDexMangaList(payload), error: "" };
    } catch (error) {
      return {
        items: [] as MangaDexManga[],
        error: error instanceof Error ? error.message : "No se pudo buscar en MangaDex",
      };
    }
  });

export const mangaDexFeed = createServerFn({ method: "GET" })
  .inputValidator((input: unknown) =>
    z
      .object({ limit: z.number().int().min(1).max(20).optional() })
      .optional()
      .parse(input),
  )
  .handler(async ({ data }) => {
    try {
      const params = new URLSearchParams({
        limit: String(data?.limit ?? 12),
        "order[updatedAt]": "desc",
        "contentRating[]": "safe",
        "includes[]": "cover_art",
      });
      params.append("availableTranslatedLanguage[]", "es");
      params.append("availableTranslatedLanguage[]", "es-la");
      const payload = await cached(`feed:${params}`, () => requestJson(`/manga?${params}`));
      return { items: parseMangaDexMangaList(payload), error: "" };
    } catch (error) {
      return {
        items: [] as MangaDexManga[],
        error: error instanceof Error ? error.message : "No se pudo cargar MangaDex",
      };
    }
  });

export const mangaDexChapters = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) =>
    z
      .object({ mangaId: z.string().uuid(), limit: z.number().int().min(1).max(100).optional() })
      .parse(input),
  )
  .handler(async ({ data }) => {
    try {
      const params = new URLSearchParams({
        limit: String(data.limit ?? 100),
        "order[chapter]": "asc",
        "order[publishAt]": "asc",
      });
      params.append("manga[]", data.mangaId);
      params.append("translatedLanguage[]", "es");
      params.append("translatedLanguage[]", "es-la");
      const payload = await cached(`chapters:${params}`, () => requestJson(`/chapter?${params}`));
      return { chapters: parseMangaDexChapters(payload), error: "" };
    } catch (error) {
      return {
        chapters: [] as MangaDexChapter[],
        error: error instanceof Error ? error.message : "No se pudieron cargar los capítulos",
      };
    }
  });

export const importMangaDex = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) =>
    z.object({ mangaId: z.string().uuid(), chapterId: z.string().uuid().optional() }).parse(input),
  )
  .handler(async ({ data }) => {
    try {
      const mangaPayload = await cached(`manga:${data.mangaId}`, () =>
        requestJson(`/manga/${data.mangaId}?includes[]=cover_art`),
      );
      const manga = parseMangaDexMangaList(mangaPayload)[0];
      if (!manga)
        return {
          ok: false as const,
          error: "No encontré el manga en MangaDex.",
          images: [],
          title: "",
          synopsis: "",
          cover: "",
          sourceUrl: "",
        };
      const chapterList = await mangaDexChapters({ data: { mangaId: data.mangaId, limit: 100 } });
      const chapter = data.chapterId
        ? chapterList.chapters.find((item) => item.id === data.chapterId)
        : chapterList.chapters[0];
      if (!chapter)
        return {
          ok: false as const,
          error: "No encontré capítulos en español para esta obra.",
          images: [],
          title: manga.title,
          synopsis: manga.synopsis,
          cover: manga.cover ?? "",
          sourceUrl: manga.sourceUrl,
        };
      const atHome = await cached(`at-home:${chapter.id}`, () =>
        requestJson<{ baseUrl: string; chapter: { hash: string; data: string[] } }>(
          `/at-home/server/${chapter.id}`,
        ),
      );
      const images = mangaDexImageUrls(atHome.baseUrl, atHome.chapter);
      return {
        ok: true as const,
        error: "",
        images,
        title: manga.title,
        synopsis: manga.synopsis,
        cover: manga.cover ?? images[0] ?? "",
        sourceUrl: `https://mangadex.org/chapter/${chapter.id}`,
        chapter,
      };
    } catch (error) {
      return {
        ok: false as const,
        error: error instanceof Error ? error.message : "No se pudo importar desde MangaDex",
        images: [],
        title: "",
        synopsis: "",
        cover: "",
        sourceUrl: "",
      };
    }
  });
