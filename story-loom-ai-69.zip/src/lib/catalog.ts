import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { SeasonId } from "./seasons";

export const CATEGORIES = [
  "Acción",
  "Protagonistas rotos",
  "Isekai",
  "Mazmorras",
  "Venganza",
  "Subir de nivel",
] as const;

export const TAGS = [
  { id: "reaccion", label: "Reacción" },
  { id: "monstruo", label: "Monstruo" },
  { id: "poder", label: "Poder" },
  { id: "primer_plano", label: "Primer plano" },
  { id: "personaje", label: "Personaje" },
  { id: "lugar", label: "Lugar" },
  { id: "accion", label: "Acción" },
  { id: "objeto", label: "Objeto" },
  { id: "escena", label: "Escena" },
] as const;

export type Work = {
  id: string;
  title: string;
  category: string;
  synopsis: string;
  protagonist: string;
  premise: string;
  conflict: string;
  reveal: string;
  climax: string;
  twist: string;
  cover_path: string | null;
  source_url: string | null;
  owner_id?: string | null;
  season?: SeasonId | null;
};
export type Panel = {
  id: string;
  work_id: string;
  path: string;
  position: number;
  tag: string;
  description: string;
};

/** Same-origin proxied URL for a remote panel image. */
export function img(url: string | null | undefined, referer?: string | null) {
  if (!url) return "";
  return `/api/img?u=${encodeURIComponent(url)}${referer ? `&r=${encodeURIComponent(referer)}` : ""}`;
}

export const worksQuery = () =>
  queryOptions({
    queryKey: ["works"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("works")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data as Work[];
    },
  });

export const workQuery = (id: string) =>
  queryOptions({
    queryKey: ["work", id],
    queryFn: async () => {
      const [w, p] = await Promise.all([
        supabase.from("works").select("*").eq("id", id).maybeSingle(),
        supabase.from("panels").select("*").eq("work_id", id).order("position"),
      ]);
      if (w.error) throw w.error;
      if (p.error) throw p.error;
      return { work: w.data as Work | null, panels: (p.data ?? []) as Panel[] };
    },
  });
