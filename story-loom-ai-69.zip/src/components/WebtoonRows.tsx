import { useEffect, useRef, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { ChevronLeft, ChevronRight, Heart, Loader2, Sparkles } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { img, type Work } from "@/lib/catalog";
import { beatsFromSynopsis, recommend } from "@/lib/recommend";
import { importWebtoon, listActionWebtoons, type WebtoonItem } from "@/lib/webtoons.functions";

const LIKES_KEY = "samumanga:likes";

export function WebtoonRows({ works }: { works: Work[] }) {
  const list = useServerFn(listActionWebtoons);
  const { data, isLoading } = useQuery({
    queryKey: ["webtoons-action"],
    queryFn: () => list(),
    staleTime: 1000 * 60 * 30,
  });
  const [likes, setLikes] = useState<string[]>([]);
  const [count, setCount] = useState(3);
  useEffect(() => {
    try {
      setLikes(JSON.parse(localStorage.getItem(LIKES_KEY) ?? "[]"));
    } catch {}
  }, []);
  const toggleLike = (id: string) =>
    setLikes((l) => {
      const n = l.includes(id) ? l.filter((x) => x !== id) : [...l, id];
      localStorage.setItem(LIKES_KEY, JSON.stringify(n));
      return n;
    });

  if (isLoading)
    return (
      <p className="flex items-center gap-2 px-6 text-muted-foreground md:px-12">
        <Loader2 className="h-4 w-4 animate-spin" /> Cargando acción de Webtoon…
      </p>
    );
  const items = data?.items ?? [];
  if (items.length === 0)
    return (
      <p className="px-6 text-muted-foreground md:px-12">
        {data?.error || "No hay obras de acción disponibles ahora."}
      </p>
    );

  const fresh = items.filter((i) => i.isNew);
  const recs = recommend(items, likes);
  const liked = items.filter((i) => likes.includes(i.titleNo));
  const props = { works, likes, toggleLike, count };

  return (
    <div className="space-y-10">
      <div className="flex flex-wrap items-center gap-2 px-6 md:px-12">
        <span className="text-sm text-muted-foreground">Shorts por obra:</span>
        {[1, 3, 5].map((n) => (
          <button
            key={n}
            onClick={() => setCount(n)}
            className={`rounded px-3 py-1 text-sm font-semibold ${count === n ? "bg-primary text-primary-foreground" : "bg-secondary text-secondary-foreground"}`}
          >
            {n}
          </button>
        ))}
      </div>
      {fresh.length > 0 && (
        <WRow title={`Nuevas en Webtoon · ${fresh.length} estrenos`} items={fresh} {...props} />
      )}
      {recs.length > 0 && <WRow title="Porque te gustó…" items={recs} {...props} />}
      {liked.length > 0 && <WRow title="Tus favoritas" items={liked} {...props} />}
      <WRow title="Acción en Webtoon" items={items} {...props} />
    </div>
  );
}

function WRow({
  title,
  items,
  works,
  likes,
  toggleLike,
  count,
}: {
  title: string;
  items: WebtoonItem[];
  works: Work[];
  likes: string[];
  toggleLike: (id: string) => void;
  count: number;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const scroll = (d: number) =>
    ref.current?.scrollBy({ left: d * ref.current.clientWidth * 0.8, behavior: "smooth" });
  return (
    <section className="group/row relative">
      <h2 className="mb-3 px-6 text-xl font-semibold md:px-12">{title}</h2>
      <button
        onClick={() => scroll(-1)}
        aria-label="Anterior"
        className="absolute left-0 top-10 z-10 hidden h-[calc(100%-2.5rem)] w-10 items-center justify-center bg-background/60 group-hover/row:flex"
      >
        <ChevronLeft />
      </button>
      <div
        ref={ref}
        className="no-scrollbar flex gap-3 overflow-x-auto scroll-smooth px-6 md:px-12"
      >
        {items.map((w) => (
          <Card
            key={w.titleNo}
            w={w}
            existing={works.find((x) => x.source_url === w.url)}
            liked={likes.includes(w.titleNo)}
            onLike={() => toggleLike(w.titleNo)}
            count={count}
          />
        ))}
      </div>
      <button
        onClick={() => scroll(1)}
        aria-label="Siguiente"
        className="absolute right-0 top-10 z-10 hidden h-[calc(100%-2.5rem)] w-10 items-center justify-center bg-background/60 group-hover/row:flex"
      >
        <ChevronRight />
      </button>
    </section>
  );
}

function Card({
  w,
  existing,
  liked,
  onLike,
  count,
}: {
  w: WebtoonItem;
  existing: Work | undefined;
  liked: boolean;
  onLike: () => void;
  count: number;
}) {
  const imp = useServerFn(importWebtoon);
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [busy, setBusy] = useState(false);

  async function makeShorts() {
    if (existing)
      return navigate({ to: "/obra/$id", params: { id: existing.id }, search: { shorts: count } });
    setBusy(true);
    try {
      toast.info(`Extrayendo el capítulo 1 de ${w.title}…`);
      const r = await imp({ data: { url: w.url } });
      if (!r.ok) return void toast.error(r.error);
      const { data: auth } = await supabase.auth.getUser();
      if (!auth.user) return void toast.error("Inicia sesión para guardar obras.");
      const synopsis = r.synopsis || w.title;
      const { data, error } = await supabase
        .from("works")
        .insert({
          owner_id: auth.user.id,
          title: w.title,
          category: "Acción",
          synopsis,
          protagonist: "nuestro protagonista",
          ...beatsFromSynopsis(synopsis),
          cover_path: w.cover || r.cover || null,
          source_url: w.url,
        })
        .select("id")
        .single();
      if (error || !data) return void toast.error("No se pudo guardar la obra.");
      await supabase
        .from("panels")
        .insert(r.images.map((path, position) => ({ work_id: data.id, path, position })));
      await qc.invalidateQueries({ queryKey: ["works"] });
      navigate({ to: "/obra/$id", params: { id: data.id }, search: { shorts: count } });
    } catch {
      toast.error("No se pudo leer la obra en webtoons.com.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="group relative w-40 shrink-0 md:w-48">
      <div className="relative aspect-[2/3] overflow-hidden rounded-md bg-card">
        <img
          src={img(w.cover, "https://www.webtoons.com/")}
          alt={w.title}
          loading="lazy"
          className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
        />
        {w.isNew && (
          <span className="absolute left-2 top-2 rounded bg-primary px-2 py-0.5 text-xs font-bold text-primary-foreground">
            NUEVA
          </span>
        )}
        <button
          onClick={onLike}
          aria-label={liked ? "Quitar me gusta" : "Me gusta"}
          className="absolute right-2 top-2 rounded-full bg-background/70 p-1.5"
        >
          <Heart className={`h-4 w-4 ${liked ? "fill-primary text-primary" : ""}`} />
        </button>
        <button
          onClick={makeShorts}
          disabled={busy}
          className="absolute inset-x-2 bottom-2 flex items-center justify-center gap-1 rounded bg-foreground py-2 text-sm font-semibold text-background opacity-0 transition-opacity group-hover:opacity-100 disabled:opacity-100"
        >
          {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}{" "}
          Hacer {count} shorts
        </button>
      </div>
      <p className="mt-2 truncate text-sm font-semibold">{w.title}</p>
      <p className="truncate text-xs text-muted-foreground">
        {w.author}
        {w.likes ? ` · ♥ ${w.likes}` : ""}
      </p>
    </div>
  );
}
