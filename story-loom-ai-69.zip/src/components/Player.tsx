import { useEffect, useMemo, useRef, useState } from "react";
import { Download, Loader2, Pause, Play, Square } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { img, type Panel } from "@/lib/catalog";
import { DEFAULT_PREFS, keywordSet, type Prefs, type Video } from "@/lib/script-engine";
import { ttsLine, VOICES } from "@/lib/tts.functions";
import { boom, MUSIC_STYLES, REAL_TRACKS, renderMusic, riser, whoosh, type MusicStyle } from "@/lib/sound";
import { saveRender } from "@/lib/studio";
import { DEFAULT_VOICE, NARRATION_STYLES, narrationProsody, type NarrationStyle } from "@/lib/narration";

const W = 720;
const H = 1280;
const GAP = 0.12; // silence between lines (s)

type Props = {
  video: Video;
  panels: Panel[];
  referer: string | null;
  title?: string;
  index?: number;
  prefs?: Prefs;
  autoExport?: boolean;
  onExported?: (ok: boolean) => void;
};
type Word = { offset: number; duration: number; text?: string };
type Seg = { start: number; dur: number; buf: AudioBuffer; words: Word[] };

const ttsCache = new Map<string, Promise<{ audio: string; words: { offset: number; duration: number; text: string }[] }>>();
const musicCache = new Map<string, Promise<AudioBuffer>>();
const clean = (w: string) => w.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^\w]/g, "");

export function Player({ video, panels, referer, title = "short", index = 1, prefs = DEFAULT_PREFS, autoExport, onExported }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const images = useRef(new Map<string, HTMLImageElement>());
  const ctxRef = useRef<AudioContext | null>(null);
  const run = useRef<{ t0: number; segs: Seg[]; total: number; nodes: AudioScheduledSourceNode[] } | null>(null);
  const musicFile = useRef<File | null>(null);
  const fileBuf = useRef<AudioBuffer | null>(null);
  const [voice, setVoice] = useState<string>(DEFAULT_VOICE);
  const [style, setStyle] = useState<NarrationStyle>(video.narrationStyle ?? "epico");
  const recorder = useRef<MediaRecorder | null>(null);
  const cancelled = useRef(false);
  const preparing = useRef(false);
  const [rate, setRate] = useState(video.narrationStyle ? NARRATION_STYLES.find((s) => s.id === video.narrationStyle)?.rate ?? prefs.rate : prefs.rate);
  const [music, setMusic] = useState<string>(prefs.music);
  const [musicVol, setMusicVol] = useState(0.22);
  const [fx, setFx] = useState(prefs.fx);
  const [musicName, setMusicName] = useState("");
  const [status, setStatus] = useState<"idle" | "loading" | "playing" | "paused" | "export">("idle");
  const [progress, setProgress] = useState(0);
  const [current, setCurrent] = useState(-1);
  const keywords = useMemo(() => [...keywordSet()].map((k) => k.trim()).filter((k) => k.length > 3), []);
  const panelById = useMemo(() => new Map(panels.map((p) => [p.id, p])), [panels]);
  const isImpact = (w: string) => keywords.some((k) => clean(w).startsWith(k));

  useEffect(() => { setFx(prefs.fx); setMusic(prefs.music); }, [prefs.fx, prefs.music]);
  useEffect(() => () => { stopAll(); ctxRef.current?.close(); }, []);

  useEffect(() => {
    for (const l of video.lines) {
      for (const id of [l.panelId, l.panelId2]) {
        const p = id ? panelById.get(id) : null;
        if (p && !images.current.has(p.id)) {
          const im = new Image();
          im.crossOrigin = "anonymous";
          im.src = img(p.path, referer);
          images.current.set(p.id, im);
        }
      }
    }
  }, [video, panelById, referer]);

  // Render loop: pure function of the audio clock
  useEffect(() => {
    let raf = 0;
    const ctx = canvasRef.current?.getContext("2d");
    let lastLine = -2;
    const draw = () => {
      raf = requestAnimationFrame(draw);
      if (!ctx) return;
      const r = run.current;
      const now = r && ctxRef.current ? ctxRef.current.currentTime - r.t0 : -1;
      let li = 0, t = 0, wi = -1, local = 0;
      if (r && now >= 0) {
        li = r.segs.findIndex((s, i) => now < (r.segs[i + 1]?.start ?? Infinity));
        if (li < 0) li = r.segs.length - 1;
        const s = r.segs[li];
         if (!s) return;
        t = Math.min(Math.max((now - s.start) / (s.dur + GAP), 0), 1);
        local = now - s.start;
        wi = s.words.reduce((a, w, k) => (local >= w.offset ? k : a), -1);
        if (li !== lastLine) { lastLine = li; setCurrent(li); }
        if (status === "export" || status === "playing") setProgress(Math.min(now / r.total, 1));
      }
      const line = video.lines[li];
      ctx.fillStyle = "#050505";
      ctx.fillRect(0, 0, W, H);
      if (!line) return;
      const marks = r?.segs[li]?.words;
       const words = marks?.length ? marks.map((w) => w.text ?? "") : line.text.split(/\s+/).filter(Boolean);
      const activeWord = wi >= 0 ? words[Math.min(wi, words.length - 1)] ?? "" : "";
      const impactWord = wi >= 0 && isImpact(activeWord);

      // Two shots per line: wide first half, second panel / punch-in second half.
      const second = t >= 0.5;
      const shotT = second ? (t - 0.5) * 2 : t * 2;
      const id = second ? line.panelId2 ?? line.panelId : line.panelId;
      const im = id ? images.current.get(id) : undefined;
      if (im && im.complete && im.naturalWidth) {
        const iw = im.naturalWidth, ih = im.naturalHeight;
        // Blurred fill so the 9:16 frame is never empty.
        const cover = Math.max(W / iw, H / ih) * 1.15;
        ctx.save();
        ctx.filter = "blur(28px) brightness(0.45) saturate(1.3)";
        ctx.drawImage(im, (W - iw * cover) / 2, (H - ih * cover) / 2, iw * cover, ih * cover);
        ctx.restore();
        // Foreground: fit width, punch-in on the second shot or impact tags.
        const punch = second || line.tag === "primer_plano";
        const impact = line.tag === "monstruo" || line.tag === "accion" || line.tag === "poder";
        let zoom = punch ? 1.35 + 0.12 * shotT : 1.02 + 0.06 * shotT;
        if (impact && !second) zoom = 1.05 + 0.35 * Math.exp(-7 * shotT);
        const base = W / iw;
        const dw = iw * base * zoom;
        const dh = ih * base * zoom;
        // Smooth elastic pulse (no random shake) with soft directional motion blur on impacts.
        const pulse = impactWord ? Math.sin(fx * Math.PI) * 0.04 : 0;
        const ease = 1 - Math.pow(1 - Math.min(1, shotT), 3);
        const pw = dw * (1 + pulse), ph = dh * (1 + pulse);
        const x = (W - pw) / 2 + (punch ? (0.5 - ease) * (pw - W) * 0.3 : 0);
        const focusY = punch ? 0.35 : 0.5;
        const y = ph > H ? -(ph - H) * (punch ? focusY : ease * 0.8 + 0.1) : (H - ph) * 0.42 - (punch ? ph * 0.05 : 0);
        const blurPx = shotT < 0.1 ? 4 * (1 - shotT / 0.1) : impactWord ? 3 * fx : 0;
        if (blurPx > 0.3) ctx.filter = `blur(${blurPx.toFixed(1)}px)`;
        // Fade in on each cut instead of a white flash.
        ctx.globalAlpha = r || shotT >= 0.12 ? (shotT < 0.12 ? 0.4 + 0.6 * (shotT / 0.12) : 1) : Math.min(1, shotT / 0.12);
        ctx.drawImage(im, x, y, pw, ph);
        ctx.globalAlpha = 1;
        ctx.filter = "none";
      }
      // Vignette
      const g = ctx.createRadialGradient(W / 2, H / 2, H * 0.25, W / 2, H / 2, H * 0.75);
      g.addColorStop(0, "rgba(0,0,0,0)");
      g.addColorStop(1, "rgba(0,0,0,0.55)");
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, W, H);

      // Kinetic captions: 1–2 words at a time, centred, active word pops.
      const cw = Math.max(wi, 0);
      const startW = Math.floor(cw / 2) * 2;
      const chunk = words.slice(startW, startW + 2);
      const size = Math.round(92 * prefs.captionScale);
      const cy = H * 0.64;
      ctx.textAlign = "left";
      ctx.textBaseline = "middle";
      ctx.font = `900 ${size}px Barlow, sans-serif`;
      const widths = chunk.map((w) => ctx.measureText(w.toUpperCase()).width);
      const totalW = widths.reduce((a, b) => a + b, 0) + (chunk.length - 1) * size * 0.25;
      const fits = totalW < W - 60;
      let cx = (W - (fits ? totalW : widths[0] ?? 0)) / 2;
      chunk.forEach((w, k) => {
        const gi = startW + k;
        const active = gi === wi;
        const word = w.toUpperCase();
        const wordStart = r?.segs[li]?.words[gi]?.offset ?? 0;
        const age = Math.max(0, local - wordStart);
        const pop = active ? 1 + 0.18 * Math.exp(-age * 14) : 1;
        const yy = fits ? cy : cy + k * size * 1.05 - size * 0.5;
        const wordWidth = widths[k] ?? 0;
         const xx = fits ? cx : (W - wordWidth) / 2;
        ctx.save();
        ctx.translate(xx + wordWidth / 2, yy);
        ctx.scale(pop, pop);
        ctx.lineJoin = "round";
        ctx.lineWidth = size * 0.2;
        ctx.strokeStyle = "#000";
        ctx.strokeText(word, -wordWidth / 2, 0);
        ctx.fillStyle = active ? (isImpact(w) ? "#ff3030" : "#ffe000") : "#ffffff";
        ctx.fillText(word, -wordWidth / 2, 0);
        ctx.restore();
        cx += wordWidth + size * 0.25;
      });
    };
    draw();
    return () => cancelAnimationFrame(raf);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [video, keywords, status, fx, prefs.captionScale]);

  function audioCtx() {
    if (!ctxRef.current || ctxRef.current.state === "closed") ctxRef.current = new AudioContext();
    return ctxRef.current;
  }

  async function buildSegments(ac: AudioContext): Promise<Seg[]> {
    const pct = Math.round((rate - 1) * 100);
    let done = 0;
    const res = await Promise.all(
      video.lines.map(async (l) => {
        const { pitch } = narrationProsody(style, l.beat);
         const key = `${voice}|${pct}|${pitch}|${l.text}`;
        if (!ttsCache.has(key)) {
          const p = ttsLine({ data: { text: l.text, voice, rate: pct, pitch } });
          p.catch(() => ttsCache.delete(key));
          ttsCache.set(key, p);
        }
        const pending = ttsCache.get(key);
         if (!pending) throw new Error("No se pudo preparar la voz");
         const r = await pending;
        const bytes = Uint8Array.from(atob(r.audio), (c) => c.charCodeAt(0));
        const buf = await ac.decodeAudioData(bytes.buffer);
        setProgress(++done / video.lines.length);
        let words = r.words;
        if (!words.length) {
          // Fallback voice has no word marks: spread words over the real decoded duration.
          const toks = l.text.split(/\s+/).filter(Boolean);
          const total = toks.reduce((a, t) => a + t.length + 1, 0) || 1;
          let acc = 0;
          words = toks.map((t) => { const w = { offset: (acc / total) * buf.duration, duration: ((t.length + 1) / total) * buf.duration, text: t }; acc += t.length + 1; return w; });
        }
        return { buf, words };
      }),
    );
    let start = 0.35;
    return res.map((r) => {
      const s = { start, dur: r.buf.duration, buf: r.buf, words: r.words };
      start += r.buf.duration + GAP;
      return s;
    });
  }

  async function musicBuffer(ac: AudioContext): Promise<AudioBuffer | null> {
    if (music === "ninguna") return null;
    if (music === "archivo") {
      if (!musicFile.current) return null;
      if (!fileBuf.current) fileBuf.current = await ac.decodeAudioData(await musicFile.current.arrayBuffer());
      return fileBuf.current;
    }
    const real = REAL_TRACKS[music];
    if (real && !musicCache.has(music)) {
      musicCache.set(music, fetch(real.url).then((r) => r.arrayBuffer()).then((b) => ac.decodeAudioData(b)));
    }
    if (!musicCache.has(music)) musicCache.set(music, renderMusic(music as MusicStyle));
    return musicCache.get(music) ?? null;
  }

  function stopAll() {
    run.current?.nodes.forEach((n) => { try { n.stop(); } catch {} });
    run.current = null;
  }

  async function start(out?: AudioNode): Promise<number> {
    const ac = audioCtx();
    await ac.resume();
    stopAll();
    setStatus("loading");
    setProgress(0);
    const [segs, mbuf] = await Promise.all([buildSegments(ac), musicBuffer(ac)]);
    if (cancelled.current) throw new Error("Preparación cancelada");
     const last = segs.at(-1);
     const total = last ? last.start + last.dur + 0.7 : 1;
    const t0 = ac.currentTime + 0.1;
    const nodes: AudioScheduledSourceNode[] = [];
    const bus = ac.createGain();
    bus.connect(ac.destination);
    if (out) bus.connect(out);
    for (const s of segs) {
      const src = ac.createBufferSource();
      src.buffer = s.buf;
      src.connect(bus);
      src.start(t0 + s.start);
      nodes.push(src);
    }
    // FX: riser into the hook, whoosh on every cut, boom on the first impact word of each line.
    if (fx > 0) {
      const fxBus = ac.createGain();
      fxBus.gain.value = Math.min(fx, 1.5);
      fxBus.connect(bus);
      riser(ac, fxBus, t0, 0.35, fx);
      segs.forEach((s, i) => {
        whoosh(ac, fxBus, t0 + s.start - 0.12, 0.9);
        whoosh(ac, fxBus, t0 + s.start + (s.dur + GAP) / 2 - 0.12, 0.6);
        const words = s.words.map((w) => w.text ?? "");
        const k = words.findIndex((w) => isImpact(w));
        const mark = k >= 0 ? s.words[Math.min(k, s.words.length - 1)] : undefined;
        if (mark) boom(ac, fxBus, t0 + s.start + mark.offset, 0.9);
      });
    }
    if (mbuf) {
      const m = ac.createBufferSource();
      m.buffer = mbuf;
      m.loop = true;
      const mg = ac.createGain();
      // Duck the music under the voice, lift it in the gaps.
      mg.gain.setValueAtTime(musicVol, t0);
      for (const s of segs) {
        mg.gain.setTargetAtTime(musicVol * 0.55, t0 + s.start - 0.05, 0.05);
        mg.gain.setTargetAtTime(musicVol, t0 + s.start + s.dur, 0.08);
      }
      mg.gain.setValueAtTime(musicVol, t0 + total - 0.8);
      mg.gain.linearRampToValueAtTime(0, t0 + total);
      m.connect(mg);
      mg.connect(bus);
      m.start(t0);
      m.stop(t0 + total);
      nodes.push(m);
    }
    run.current = { t0, segs, total, nodes };
    return total;
  }

  async function play() {
    if (status === "paused") { await ctxRef.current?.resume(); setStatus("playing"); return; }
     if (preparing.current) return;
     preparing.current = true;
     cancelled.current = false;
    try {
      const total = await start();
      setStatus("playing");
      const r = run.current;
      const timer = window.setInterval(() => {
         if (run.current !== r) { clearInterval(timer); return; }
         if (r && acTime() >= r.t0 + total) { clearInterval(timer); stop(); }
       }, 50);
    } catch (e) {
      setStatus("idle");
      if (!cancelled.current) toast.error(`No se pudo generar la voz: ${(e as Error).message}`);
    } finally { preparing.current = false; }
  }
  async function pause() { await ctxRef.current?.suspend(); setStatus("paused"); }
  function acTime() { return ctxRef.current?.currentTime ?? 0; }
  function stop() {
    cancelled.current = true;
    if (recorder.current?.state !== "inactive") recorder.current?.stop();
    stopAll();
    ctxRef.current?.resume();
    setStatus("idle");
    setCurrent(-1);
    setProgress(0);
  }

  async function exportVideo() {
    const canvas = canvasRef.current;
    if (preparing.current) return;
     if (!canvas || typeof canvas.captureStream !== "function" || typeof MediaRecorder === "undefined") { toast.error("Tu navegador no permite grabar video."); onExported?.(false); return; }
    preparing.current = true;
    cancelled.current = false;
    const ac = audioCtx();
    const dest = ac.createMediaStreamDestination();
    let stream: MediaStream | null = null;
    let ok = false;
    try {
      setStatus("loading");
      setProgress(0);
      await Promise.all([...images.current.values()].map((im) => im.decode()));
       await document.fonts.ready;
       const total = await start(dest);
      setStatus("export");
      stream = new MediaStream([...canvas.captureStream(30).getVideoTracks(), ...dest.stream.getAudioTracks()]);
      const mime = ["video/mp4;codecs=avc1,mp4a.40.2", "video/mp4", "video/webm;codecs=vp9,opus", "video/webm"].find((m) => MediaRecorder.isTypeSupported(m)) ?? "";
      const rec = new MediaRecorder(stream, mime ? { mimeType: mime, videoBitsPerSecond: 8_000_000 } : { videoBitsPerSecond: 8_000_000 });
      recorder.current = rec;
       const parts: Blob[] = [];
      rec.ondataavailable = (e) => e.data.size && parts.push(e.data);
      let recorderError: Error | null = null;
       const finished = new Promise<void>((res) => {
         rec.onstop = () => res();
         rec.onerror = () => { recorderError = new Error("La grabación falló"); stop(); res(); };
       });
      rec.start(500);
      const r = run.current;
      await new Promise<void>((res) => {
        const timer = window.setInterval(() => {
          if (run.current !== r || cancelled.current || (r && acTime() >= r.t0 + total)) { clearInterval(timer); res(); }
        }, 30);
      });
      if (rec.state !== "inactive") rec.stop();
      await finished;
      if (recorderError) throw recorderError;
      if (cancelled.current || run.current !== r) return;
      const actualMime = rec.mimeType || mime || "video/webm";
      const ext = actualMime.includes("mp4") ? "mp4" : "webm";
      const blob = new Blob(parts, { type: actualMime });
      const slug = title.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
      const filename = `${slug || "short"}-video-${index}-${new Date().toISOString().slice(0, 10)}.${ext}`;
      await saveRender({ id: video.id, videoId: video.id, title: `${title} · Video ${index}`, filename, blob, createdAt: Date.now() }).catch(() => {});
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = filename;
      a.click();
      setTimeout(() => URL.revokeObjectURL(a.href), 10000);
      toast.success(`Video ${index} descargado y guardado en "Mis videos"`);
      ok = true;
    } catch (e) {
      toast.error(`No se pudo exportar: ${(e as Error).message}`);
    } finally {
      stream?.getTracks().forEach((track) => track.stop());
      dest.disconnect();
      recorder.current = null;
      stop();
      preparing.current = false;
      onExported?.(ok);
    }
  }

  useEffect(() => {
    if (autoExport && status === "idle") exportVideo();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [autoExport]);

  useEffect(() => {
     const visible = () => {
       if (document.hidden && recorder.current?.state === "recording") {
         stop();
         toast.error("Grabación cancelada: mantén esta pestaña visible para no perder la sincronización.");
       }
     };
     document.addEventListener("visibilitychange", visible);
     return () => document.removeEventListener("visibilitychange", visible);
   }, []);

   const busy = status === "loading" || status === "export";
   const controlsLocked = status !== "idle";

  return (
    <div className="flex flex-col gap-4">
      <canvas ref={canvasRef} width={W} height={H} className="aspect-[9/16] w-full shrink-0 max-w-[340px] rounded-lg border border-border bg-card shadow-2xl" />
      <div className="flex min-w-0 flex-1 flex-col gap-4">
        <div className="flex flex-wrap gap-2">
          {status === "playing" ? (
            <Button onClick={pause}><Pause className="mr-1 h-4 w-4" />Pausar</Button>
          ) : (
            <Button onClick={play} disabled={busy}><Play className="mr-1 h-4 w-4" />Reproducir</Button>
          )}
          <Button variant="secondary" onClick={stop} disabled={status === "idle"}><Square className="mr-1 h-4 w-4" />{status === "export" ? "Cancelar" : "Detener"}</Button>
          <Button variant="outline" onClick={exportVideo} disabled={busy || status === "playing"}>
            {busy ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : <Download className="mr-1 h-4 w-4" />}Descargar este video
          </Button>
          <Button variant="outline" onClick={() => { navigator.clipboard.writeText(`${video.lines[0]?.text ?? title} | ${title} #shorts #manhwa #webtoon #recap`).then(() => toast.success("Título y hashtags copiados")); }}>Copiar título y hashtags</Button>
        </div>
        {status !== "idle" && (
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground">
              {status === "loading" ? "Preparando voz y música…" : status === "export" ? "Grabando el video (tarda lo mismo que dura)…" : "Reproduciendo"} {Math.round(progress * 100)}%
            </p>
            <Progress value={progress * 100} />
          </div>
        )}
        <div className="space-y-2">
           <Label>Estilo de narración</Label>
           <Select value={style} disabled={controlsLocked} onValueChange={(value) => {
             const preset = NARRATION_STYLES.find((s) => s.id === value);
             if (!preset) return;
             setStyle(preset.id); setRate(preset.rate);
           }}>
             <SelectTrigger aria-label="Estilo de narración"><SelectValue /></SelectTrigger>
             <SelectContent>{NARRATION_STYLES.map((s) => <SelectItem key={s.id} value={s.id}>{s.label}</SelectItem>)}</SelectContent>
           </Select>
         </div>
         <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-2">
            <Label>Voz</Label>
            <Select value={voice} onValueChange={setVoice} disabled={controlsLocked}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{VOICES.map((v) => <SelectItem key={v.id} value={v.id}>{v.label}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Música</Label>
            <Select value={music} onValueChange={setMusic} disabled={controlsLocked}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{MUSIC_STYLES.map((m) => <SelectItem key={m.id} value={m.id}>{m.label}</SelectItem>)}</SelectContent>
            </Select>
          </div>
        </div>
        {music === "archivo" && (
          <input
            type="file"
            accept="audio/*"
            disabled={busy}
            className="block w-full text-sm text-muted-foreground file:mr-3 file:rounded file:border-0 file:bg-secondary file:px-3 file:py-1.5 file:text-secondary-foreground"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (!f) return;
              musicFile.current = f;
              fileBuf.current = null;
              setMusicName(f.name);
            }}
          />
        )}
        {musicName && music === "archivo" && <p className="text-xs text-muted-foreground">{musicName}</p>}
        {REAL_TRACKS[music] && (
          <audio key={music} controls preload="none" src={REAL_TRACKS[music].url} className="w-full" aria-label="Escuchar canción" />
        )}
        <div className="space-y-2">
          <Label>Velocidad de voz: {rate.toFixed(2)}x</Label>
          <Slider min={0.8} max={1.6} step={0.05} value={[rate]} disabled={controlsLocked} onValueChange={([v]) => setRate(v ?? 1)} />
        </div>
        <div className="space-y-2">
          <Label>Volumen música: {Math.round(musicVol * 100)}%</Label>
          <Slider min={0} max={0.6} step={0.01} value={[musicVol]} disabled={controlsLocked} onValueChange={([v]) => setMusicVol(v ?? 0)} />
        </div>
        <div className="space-y-2">
          <Label>Efectos de sonido (whoosh, golpes): {Math.round(fx * 100)}%</Label>
          <Slider min={0} max={1.5} step={0.05} value={[fx]} disabled={controlsLocked} onValueChange={([v]) => setFx(v ?? 0)} />
        </div>
        {current >= 0 && status !== "idle" && (
          <p className="rounded bg-muted p-3 text-sm">
            <span className="font-semibold text-primary">Frase {current + 1}/{video.lines.length}:</span> {video.lines[current]?.text}
          </p>
        )}
      </div>
    </div>
  );
}
