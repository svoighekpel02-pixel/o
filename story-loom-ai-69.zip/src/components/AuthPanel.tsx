import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";

export function AuthPanel() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [busy, setBusy] = useState(false);

  async function submit() {
    setBusy(true);
    const result =
      mode === "login"
        ? await supabase.auth.signInWithPassword({ email, password })
        : await supabase.auth.signUp({ email, password });
    setBusy(false);
    if (result.error) {
      toast.error(result.error.message);
      return;
    }
    toast.success(
      mode === "login"
        ? "Sesión iniciada"
        : "Cuenta creada. Revisa tu correo si la confirmación está activa.",
    );
  }

  return (
    <main className="flex min-h-screen items-center justify-center px-6 py-24">
      <section className="glass-panel w-full max-w-md space-y-6 p-6 sm:p-8">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.25em] text-primary">
            SamuManga
          </p>
          <h1 className="mt-2 font-display text-5xl tracking-wide">
            {mode === "login" ? "Entrar" : "Crear cuenta"}
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Tus obras y videos quedan separados por cuenta.
          </p>
        </div>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="auth-email">Correo</Label>
            <Input
              id="auth-email"
              type="email"
              autoComplete="email"
              value={email}
              onChange={(event) => setEmail(event.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="auth-password">Contraseña</Label>
            <Input
              id="auth-password"
              type="password"
              autoComplete={mode === "login" ? "current-password" : "new-password"}
              value={password}
              onChange={(event) => setPassword(event.target.value)}
            />
          </div>
          <Button
            className="w-full"
            disabled={busy || !email || password.length < 6}
            onClick={submit}
          >
            {busy ? "Procesando…" : mode === "login" ? "Iniciar sesión" : "Registrarme"}
          </Button>
        </div>
        <Button
          variant="ghost"
          className="w-full"
          onClick={() => setMode(mode === "login" ? "signup" : "login")}
        >
          {mode === "login" ? "Crear una cuenta" : "Ya tengo cuenta"}
        </Button>
      </section>
    </main>
  );
}
