import { useEffect, useState } from "react";
import { BookOpen, Pencil, Plus, Save, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { BEAT_LABEL, uid } from "@/lib/script-engine";
import { DEFAULT_PATTERNS, loadTemplates, PLACEHOLDERS, saveTemplates, TEMPLATE_BEATS, templateErrors, type ScriptTemplate } from "@/lib/templates";

export function TemplateBank({ onApply }: { onApply?: (template: ScriptTemplate) => void }) {
  const [templates, setTemplates] = useState<ScriptTemplate[]>([]);
  const [draft, setDraft] = useState<ScriptTemplate | null>(null);
  const [error, setError] = useState("");
  const [filter, setFilter] = useState("todas");
  useEffect(() => {
    const reload = () => setTemplates(loadTemplates());
    reload();
    window.addEventListener("samumanga:templates-changed", reload);
    return () => window.removeEventListener("samumanga:templates-changed", reload);
  }, []);
  function commit(next: ScriptTemplate[]) {
    try { saveTemplates(next); setTemplates(next); return true; }
    catch { toast.error("No se pudo guardar en este navegador."); return false; }
  }
  function save() {
    if (!draft) return;
    const errors = templateErrors(draft);
    if (errors.length) { setError(errors.join(" ")); return; }
    if (commit([...templates.filter((t) => t.id !== draft.id), draft])) {
      setDraft(null);
      toast.success("Plantilla guardada en este navegador");
    }
  }
  const visible = templates.filter((t) => filter === "todas" || t.classification === filter);
  return (
    <section className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border pb-4">
        <div className="flex items-center gap-3">
          <BookOpen className="h-6 w-6 text-accent" />
          <h2 className="font-display text-3xl">Plantillas Virales</h2>
          <Badge variant="secondary">{templates.length}</Badge>
        </div>
        <Button onClick={() => { setError(""); setDraft({ id: uid(), name: "", classification: "referencia", reference: "", source: "", patterns: { ...DEFAULT_PATTERNS } }); }}><Plus className="h-4 w-4" />Nueva plantilla</Button>
      </div>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <Select value={filter} onValueChange={setFilter}>
          <SelectTrigger className="w-48" aria-label="Filtrar plantillas"><SelectValue /></SelectTrigger>
          <SelectContent><SelectItem value="todas">Todas</SelectItem><SelectItem value="10k">Template +10k</SelectItem><SelectItem value="referencia">Referencias</SelectItem></SelectContent>
        </Select>
        <span className="text-xs text-muted-foreground">Guardadas en este navegador</span>
      </div>
      {visible.length === 0 && <div className="border-y border-border py-16 text-center text-muted-foreground"><BookOpen className="mx-auto mb-4 h-9 w-9" /><p>{templates.length ? "Sin plantillas en esta categoría" : "Todavía no hay guiones de referencia"}</p></div>}
      <div className="grid gap-4 md:grid-cols-2">
        {visible.map((t) => (
          <article key={t.id} className="flex flex-col gap-4 rounded-md border border-border bg-card p-5">
            <div className="flex items-start justify-between gap-2">
              <h3 className="break-words text-lg font-semibold">{t.name}</h3>
              <Badge variant={t.classification === "10k" ? "default" : "secondary"} className="shrink-0">{t.classification === "10k" ? "Template +10k" : "Referencia"}</Badge>
            </div>
            <p className="line-clamp-4 whitespace-pre-wrap break-words text-sm text-muted-foreground">{t.reference}</p>
            {t.source && <p className="truncate text-xs text-muted-foreground">{t.source}</p>}
            <div className="mt-auto flex flex-wrap gap-2">
              {onApply && <Button size="sm" onClick={() => onApply(t)}>Aplicar plantilla</Button>}
              <Button size="icon" variant="secondary" aria-label={`Editar ${t.name}`} title="Editar plantilla" onClick={() => { setError(""); setDraft({ ...t, patterns: { ...t.patterns } }); }}><Pencil className="h-4 w-4" /></Button>
              <Button size="icon" variant="ghost" aria-label={`Eliminar ${t.name}`} title="Eliminar plantilla" onClick={() => { if (window.confirm(`¿Eliminar «${t.name}»?`)) commit(templates.filter((item) => item.id !== t.id)); }}><Trash2 className="h-4 w-4" /></Button>
            </div>
          </article>
        ))}
      </div>
      <Dialog open={draft !== null} onOpenChange={(open) => { if (!open) setDraft(null); }}>
        <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-2xl">
          <DialogHeader><DialogTitle>{templates.some((t) => t.id === draft?.id) ? "Editar plantilla" : "Nueva plantilla"}</DialogTitle></DialogHeader>
          {draft && <div className="space-y-5">
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2"><Label htmlFor="template-name">Nombre</Label><Input id="template-name" value={draft.name} maxLength={120} onChange={(e) => setDraft({ ...draft, name: e.target.value })} /></div>
              <div className="space-y-2"><Label>Clasificación</Label><Select value={draft.classification} onValueChange={(value) => setDraft({ ...draft, classification: value === "10k" ? "10k" : "referencia" })}><SelectTrigger aria-label="Clasificación"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="referencia">Referencia</SelectItem><SelectItem value="10k">Template +10k</SelectItem></SelectContent></Select></div>
            </div>
            <div className="space-y-2"><Label htmlFor="template-source">Video de referencia / YouTube</Label><Input id="template-source" value={draft.source} onChange={(e) => setDraft({ ...draft, source: e.target.value })} /></div>
            <div className="space-y-2"><Label htmlFor="template-reference">Guion de referencia</Label><Textarea id="template-reference" rows={5} maxLength={12000} value={draft.reference} onChange={(e) => setDraft({ ...draft, reference: e.target.value })} /></div>
            <h3 className="border-t border-border pt-4 font-semibold">Estructura adaptable</h3>
            {TEMPLATE_BEATS.map((beat) => <div key={beat} className="space-y-2">
              <Label htmlFor={`template-${beat}`}>{BEAT_LABEL[beat]}</Label>
              <Textarea id={`template-${beat}`} rows={2} value={draft.patterns[beat]} onChange={(e) => setDraft({ ...draft, patterns: { ...draft.patterns, [beat]: e.target.value } })} />
              <div className="flex flex-wrap gap-1">{PLACEHOLDERS.map((token) => <Button key={token} size="sm" variant="ghost" className="h-7 px-2 text-xs" title={`Insertar ${token}`} onClick={() => setDraft({ ...draft, patterns: { ...draft.patterns, [beat]: `${draft.patterns[beat]} {${token}}` } })}>{`{${token}}`}</Button>)}</div>
            </div>)}
            {error && <p role="alert" className="text-sm text-destructive">{error}</p>}
            <Button onClick={save}><Save className="h-4 w-4" />Guardar plantilla</Button>
          </div>}
        </DialogContent>
      </Dialog>
    </section>
  );
}