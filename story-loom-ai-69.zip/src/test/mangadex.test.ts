import { describe, expect, it } from "vitest";
import {
  mangaDexImageUrls,
  parseMangaDexChapters,
  parseMangaDexMangaList,
} from "@/lib/mangadex.functions";

const mangaId = "11111111-1111-4111-8111-111111111111";
const chapterId = "22222222-2222-4222-8222-222222222222";

describe("MangaDex adapter", () => {
  it("parses Spanish-preferred metadata and cover relationships", () => {
    const items = parseMangaDexMangaList({
      data: [
        {
          id: mangaId,
          attributes: { title: { es: "La historia" }, description: { "es-la": "Sinopsis" } },
          relationships: [{ type: "cover_art", attributes: { fileName: "cover.jpg" } }],
        },
      ],
    });
    expect(items[0]).toMatchObject({
      id: mangaId,
      title: "La historia",
      synopsis: "Sinopsis",
      cover: `https://uploads.mangadex.org/covers/${mangaId}/cover.jpg`,
    });
  });

  it("parses chapters and builds raw at-home URLs for the /api/img proxy", () => {
    const chapters = parseMangaDexChapters({
      data: [
        {
          id: chapterId,
          attributes: {
            chapter: "1",
            title: "Inicio",
            pages: 2,
            publishedAt: "2026-01-01T00:00:00Z",
          },
        },
      ],
    });
    expect(chapters[0]).toMatchObject({ id: chapterId, number: "1", pages: 2 });
    expect(
      mangaDexImageUrls("https://uploads.example", { hash: "hash", data: ["a.jpg", "b.jpg"] }),
    ).toEqual([
      "https://uploads.example/data/hash/a.jpg",
      "https://uploads.example/data/hash/b.jpg",
    ]);
  });
});
