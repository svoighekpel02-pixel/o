import { describe, expect, it } from "vitest";
import { recommend } from "@/lib/recommend";

const items = [
  { titleNo: "1", title: "El mercenario que regresó tiene un plan", subgenre: "action" },
  { titleNo: "2", title: "El joven señor renacido es un asesino", subgenre: "action" },
  { titleNo: "3", title: "Jugo de Jungla", subgenre: "comedy" },
];

describe("recommend", () => {
  it("returns nothing without likes", () => {
    expect(recommend(items, [])).toEqual([]);
  });
  it("suggests works sharing tropes with a liked one, excluding the liked one", () => {
    const r = recommend(items, ["1"]).map((i) => i.titleNo);
    expect(r).toEqual(["2"]);
  });
});
