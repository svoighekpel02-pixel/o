import { beforeEach, describe, expect, it } from "vitest";
import { DEFAULT_RATE, DEFAULT_VOICE, NARRATION_STYLES, dramatize, narrationProsody, validateTtsInput } from "@/lib/narration";
import { DEFAULT_PREFS, generateBatch } from "@/lib/script-engine";
import { DEFAULT_PATTERNS, applyTemplate, loadTemplates, saveTemplates, templateErrors, type ScriptTemplate } from "@/lib/templates";
import type { Work } from "@/lib/catalog";

const work: Work = { id: "w", title: "Rata", category: "Acción", synopsis: "", protagonist: "Leo", premise: "controlas una rata", conflict: "Todos se burlan de Leo.", reveal: "La rata se transforma.", climax: "La bestia destruye la torre.", twist: "El rey lo descubre.", cover_path: null, source_url: null };
const template: ScriptTemplate = { id: "t", name: "Ascenso", classification: "10k", source: "", reference: "Una historia de referencia con diez mil visitas.", patterns: { ...DEFAULT_PATTERNS, gancho: "¿Qué harías si {premisa}?", remate: "{remate}. Así comienza {titulo}." } };

describe("narration presets", () => {
  it("defaults to Jorge at precisely 1.10x", () => {
    expect(DEFAULT_VOICE).toBe("es-MX-JorgeNeural");
    expect(DEFAULT_RATE).toBe(1.10);
    expect(DEFAULT_PREFS.rate).toBe(1.10);
  });
  it("modulates rate and pitch for each requested style", () => {
    expect(NARRATION_STYLES.map((s) => [s.id, s.rate])).toEqual([["accion", 1.2], ["epico", 1.1], ["misterio", 1]]);
    expect(narrationProsody("accion", "climax").pitch).toBe(7);
    expect(narrationProsody("misterio", "gancho").pitch).toBe(-5);
  });
  it("adds spoken pauses for twists and emphasis for climax", () => {
    expect(dramatize("Pero la rata cambia.", "revelacion", "epico")).toBe("Pero… la rata cambia…");
    expect(dramatize("La torre cae.", "climax", "accion")).toBe("¡La torre cae!");
    expect(dramatize("La torre cae.", "climax", "misterio")).toBe("La torre cae…");
    const video = generateBatch(work, [], 1, "likes", DEFAULT_PREFS, { template })[0];
    expect(video?.lines.some((line) => line.text === "Pero…")).toBe(false);
    expect(video?.lines.find((line) => line.beat === "revelacion")?.text).toContain("rata");
  });
  it("validates rate and pitch before requesting audio", () => {
    expect(validateTtsInput({ text: "Hola", voice: DEFAULT_VOICE, rate: 10, pitch: 7 }, [{ id: DEFAULT_VOICE }])).toMatchObject({ rate: 10, pitch: 7 });
    expect(() => validateTtsInput({ text: "Hola", voice: DEFAULT_VOICE, rate: NaN }, [{ id: DEFAULT_VOICE }])).toThrow();
  });
});

describe("saved reference templates", () => {
  beforeEach(() => localStorage.clear());
  it("keeps pasted references and +10k classification after reload", () => {
    saveTemplates([template]);
    expect(loadTemplates()).toEqual([template]);
  });
  it("adapts the template to any work instead of narrating its reference story", () => {
    const otherWork = { ...work, title: "Dragón", premise: "controlas un dragón" };
    const lines = applyTemplate(template, otherWork);
    expect(lines[0]?.text).toBe("¿Qué harías si controlas un dragón?");
    expect(lines.at(-1)?.text).toContain("Así comienza Dragón");
    expect(lines.some((l) => l.text.includes(template.reference))).toBe(false);
  });
  it("applies a selected template to exactly the requested batch", () => {
    for (const count of [1, 3, 5]) {
      const videos = generateBatch(work, [], count, "likes", DEFAULT_PREFS, { template, narrationStyle: "accion" });
      expect(videos).toHaveLength(count);
      expect(videos.every((v) => v.templateId === "t" && v.narrationStyle === "accion")).toBe(true);
      expect(videos[0]?.lines[0]?.text).toBe("¿Qué harías si controlas una rata?");
    }
  });
  it("rejects static or unknown beat placeholders", () => {
    expect(templateErrors(template)).toEqual([]);
    expect(templateErrors({ ...template, patterns: { ...template.patterns, gancho: "La misma historia siempre" } })).toContain("Falta una variable en gancho.");
    expect(templateErrors({ ...template, patterns: { ...template.patterns, climax: "{inexistente}" } })).toContain("Variable desconocida en climax.");
  });
});