import { describe, expect, it } from "vitest";
import { generateBatch, inferTag } from "@/lib/script-engine";
import type { Panel, Work } from "@/lib/catalog";

const work: Work = {
  id: "w", title: "Rata", category: "Protagonistas rotos", synopsis: "", protagonist: "nuestro protagonista",
  premise: "despertar controlando una rata", conflict: "Todos se burlan de él.", reveal: "La rata se transforma en una bestia colosal.",
  climax: "Llega al gremio y el gerente queda sorprendido.", twist: "Le susurra que no tendrá tanta suerte.", cover_path: null, source_url: null,
};
const panels: Panel[] = [
  { id: "a", work_id: "w", path: "a", position: 0, tag: "reaccion", description: "aventureros riendo" },
  { id: "b", work_id: "w", path: "b", position: 1, tag: "monstruo", description: "bestia colosal" },
  { id: "c", work_id: "w", path: "c", position: 2, tag: "personaje", description: "gerente del gremio" },
  { id: "d", work_id: "w", path: "d", position: 3, tag: "primer_plano", description: "protagonista susurra" },
];

describe("script engine", () => {
  it("generates the requested number of videos", () => {
    expect(generateBatch(work, panels, 5, "likes")).toHaveLength(5);
  });
  it("keeps shorts to 5 lines, about 70 words, ending in the title drop", () => {
    const v = generateBatch(work, panels, 1, "suscriptores")[0]!;
    expect(v.lines.length).toBeLessThanOrEqual(5);
    expect(v.lines.map((l) => l.text).join(" ").split(/\s+/).length).toBeLessThanOrEqual(75);
    expect(v.lines.at(-1)!.text).toBe("Así comienza Rata.");
  });
  it("matches the mockery line to the laughing panel and the whisper to the close-up", () => {
    const v = generateBatch(work, panels, 1, "suscriptores")[0]!;
    expect(v.lines.find((l) => l.text.includes("burlan"))!.panelId).toBe("a");
    expect(v.lines.find((l) => l.text.includes("bestia"))!.panelId).toBe("b");
    expect(v.lines.find((l) => l.text.includes("gremio"))!.panelId).toBe("c");
  });
  it("tags whispers as close-up", () => {
    expect(inferTag("Le susurra al oído")).toBe("primer_plano");
  });
});

import { generateBatch as gb } from "@/lib/script-engine";
describe("batch scenes", () => {
  const panels = Array.from({ length: 20 }, (_, i) => ({ id: `p${i}`, work_id: "w", path: `x${i}.jpg`, position: i, tag: "escena", description: "" }));
  const work = { id: "w", title: "T", category: "Acción", synopsis: "", protagonist: "", premise: "Despiertas solo", conflict: "Uno. Dos.", reveal: "Tres.", climax: "Cuatro.", twist: "Cinco.", cover_path: null, source_url: null };
  it("never opens on the first quarter of the chapter", () => {
    for (const v of gb(work, panels, 3, "viral")) expect(Number(v.lines[0]!.panelId!.slice(1))).toBeGreaterThanOrEqual(5);
  });
  it("3 videos use different opening scenes", () => {
    const opens = new Set(gb(work, panels, 3, "viral").map((v) => v.lines[0]!.panelId));
    expect(opens.size).toBe(3);
  });
});
