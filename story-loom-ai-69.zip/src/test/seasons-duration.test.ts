import { describe, expect, it } from "vitest";
import { currentSeason, matchesSeason } from "@/lib/seasons";
import { generateBatch, SCRIPT_DURATIONS } from "@/lib/script-engine";

const work = {
  id: "w",
  title: "La bruja de invierno",
  category: "Acción",
  synopsis: "Una bruja protege la ciudad durante la Navidad.",
  protagonist: "la bruja",
  premise: "despertar con magia",
  conflict: "Todos la temen.",
  reveal: "La magia protege a la ciudad.",
  climax: "El monstruo ataca.",
  twist: "La próxima noche será peor.",
  cover_path: null,
  source_url: null,
};

describe("seasons", () => {
  it("matches seasonal metadata and text keywords", () => {
    expect(matchesSeason({ ...work, season: "navidad" }, "navidad")).toBe(true);
    expect(matchesSeason(work, "navidad")).toBe(true);
    expect(matchesSeason(work, "san_valentin")).toBe(false);
  });
  it("returns a deterministic calendar season", () => {
    expect(currentSeason(new Date("2026-10-16T12:00:00Z"))).toBe("halloween");
  });
});

describe("script duration profiles", () => {
  it("exposes all requested reference durations", () => {
    expect(SCRIPT_DURATIONS.map((profile) => profile.id)).toEqual([15, 45, 90]);
  });
  it("stores the selected duration on generated videos", () => {
    for (const duration of [15, 45, 90] as const) {
      expect(generateBatch(work, [], 1, "viral", undefined, { duration })[0]?.duration).toBe(
        duration,
      );
    }
  });
});
