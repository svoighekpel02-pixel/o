import { createFileRoute, notFound } from "@tanstack/react-router";
import { useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { Sparkles, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";
import { img, TAGS, workQuery, type Panel } from "@/lib/catalog";
import {
  BEAT_LABEL,
  generateBatch,
  GOALS,
  inferTag,
  SCRIPT_DURATIONS,
  type Goal,
  type ScriptDuration,
  type Video,
} from "@/lib/script-engine";
import { Player } from "@/components/Player";
import { TemplateBank } from "@/components/TemplateBank";
import { loadTemplates, type ScriptTemplate } from "@/lib/templates";
import { DEFAULT_PREFS } from "@/lib/script-engine";
import { NARRATION_STYLES, type NarrationStyle } from "@/lib/narration";
import { upsertVideos } from "@/lib/studio";
import { webtoonEpisodes, type Episode } from "@/lib/webtoons.functions";

const fmtDate = (ms: number) =>
  new Date(ms).toLocaleDateString("es-ES", { day: "numeric", month: "short", year: "numeric" });

export const Route = createFileRoute("/obra/$id")({
  validateSearch: (s: Record<string, unknown>): { shorts?: number; template?: string } => {
    const n = Number(s["shorts"]);
    return {
      ...(n >= 1 && n <= 10 ? { shorts: n } : {}),
      ...(typeof s["template"] === "string" ? { template: s["template"] } : {}),
    };
  },
  loader: async ({ context, params }) => {
    const d = await context.queryClient.ensureQueryData(workQuery(params.id));
    if (!d.work) throw notFound();
    return { title: d.work.title, synopsis: d.work.synopsis || d.work.premise };
  },
  head: ({ loaderData }) => ({
    meta: [
      { title: loaderData ? `${loaderData.title} — SamuManga` : "Obra — SamuManga" },
      { name: "description", content: loaderData?.synopsis || "Genera videos de esta obra." },
      {
        property: "og:title",
        content: loaderData ? `${loaderData.title} — SamuManga` : "Obra — SamuManga",
      },
      {
        property: "og:description",
        content: loaderData?.synopsis || "Genera videos de esta obra.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  notFoundComponent: () => <p className="p-32 text-center">Obra no encontrada.</p>,
  component: WorkPage,
});

function WorkPage() {
  const { id } = Route.useParams();
  const { data } = useSuspenseQuery(workQuery(id));
  const work = data.work;
  const panels = data.panels;
  const qc = useQueryClient();
  const { shorts, template: searchTemplate } = Route.useSearch();
  const [count, setCount] = useState(shorts ?? 3);
  const [goal, setGoal] = useState<Goal>("suscriptores");
  const [videos, setVideos] = useState<Video[]>([]);
  const [active, setActive] = useState("");
  const [picker, setPicker] = useState<{ video: string; line: string } | null>(null);
  const [templates, setTemplates] = useState<ScriptTemplate[]>([]);
  const [templateId, setTemplateId] = useState(searchTemplate ?? "original");
  const [style, setStyle] = useState<NarrationStyle>("epico");
  const [duration, setDuration] = useState<ScriptDuration>(15);
  const [tab, setTab] = useState("generar");
  const [episodes, setEpisodes] = useState<Episode[]>([]);
  useEffect(() => {
    if (!work?.source_url) return;
    webtoonEpisodes({ data: { url: work.source_url } })
      .then((r) => setEpisodes(r.episodes))
      .catch(() => {});
  }, [work?.source_url]);
  function setStats(videoId: string, patch: NonNullable<Video["stats"]>) {
    setVideos((vs) => {
      const next = vs.map((v) =>
        v.id === videoId ? { ...v, stats: { ...v.stats, ...patch } } : v,
      );
      upsertVideos(next);
      return next;
    });
  }
  const panelById = new Map(panels.map((p) => [p.id, p]));

  function generate() {
    if (!work) return;
    const template = loadTemplates().find((t) => t.id === templateId);
    if (templateId !== "original" && !template) {
      toast.error("La plantilla ya no está disponible.");
      return;
    }
    const preset = NARRATION_STYLES.find((s) => s.id === style);
    const v = generateBatch(
      work,
      panels,
      count,
      goal,
      { ...DEFAULT_PREFS, rate: preset?.rate ?? 1.1 },
      { ...(template ? { template } : {}), narrationStyle: style, duration },
    );
    setVideos(v);
    upsertVideos(v);
    setActive(v[0]?.id ?? "");
    toast.success(`${v.length} guiones generados`);
  }

  useEffect(() => {
    const reload = () => setTemplates(loadTemplates());
    reload();
    window.addEventListener("samumanga:templates-changed", reload);
    return () => window.removeEventListener("samumanga:templates-changed", reload);
  }, []);
  useEffect(() => {
    setTemplateId(searchTemplate ?? "original");
  }, [searchTemplate]);

  const generatedKey = useRef<string | null>(null);
  useEffect(() => {
    const key = `${id}|${shorts}|${searchTemplate ?? ""}`;
    if (!shorts || panels.length === 0 || generatedKey.current === key) return;
    generatedKey.current = key; // generate once per click, never on refetch
    generate();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [shorts, id, searchTemplate, panels.length > 0]);

  function updateLine(videoId: string, lineId: string, patch: Partial<Video["lines"][number]>) {
    setVideos((vs) =>
      vs.map((v) =>
        v.id !== videoId
          ? v
          : { ...v, lines: v.lines.map((l) => (l.id === lineId ? { ...l, ...patch } : l)) },
      ),
    );
  }

  async function updatePanel(p: Panel, patch: Partial<Panel>) {
    await supabase.from("panels").update(patch).eq("id", p.id);
    qc.invalidateQueries({ queryKey: ["work", id] });
  }
  async function deletePanel(p: Panel) {
    await supabase.from("panels").delete().eq("id", p.id);
    qc.invalidateQueries({ queryKey: ["work", id] });
  }

  if (!work) return <p className="p-32 text-center">Obra no encontrada.</p>;
  return (
    <main className="min-h-screen pb-20">
      <section className="relative h-[46vh] min-h-[320px] overflow-hidden">
        <img
          src={img(work.cover_path, work.source_url)}
          alt={work.title}
          className="absolute inset-0 h-full w-full object-cover object-top"
        />
        <div className="absolute inset-0" style={{ background: "var(--gradient-hero)" }} />
        <div className="relative flex h-full flex-col justify-end px-6 pb-8 md:px-12">
          <span className="text-sm font-semibold uppercase tracking-[0.3em] text-primary">
            {work.category}
          </span>
          <h1 className="font-display text-6xl tracking-wide">{work.title}</h1>
          <p className="max-w-2xl text-muted-foreground">{work.synopsis}</p>
          {episodes.length > 0 && (
            <div className="mt-3 flex flex-wrap items-center gap-3 text-sm">
              <Badge variant="secondary">Estreno: {fmtDate(episodes[0]!.date)}</Badge>
              <Badge variant="secondary">
                Último cap.: {fmtDate(episodes[episodes.length - 1]!.date)} · {episodes.length}{" "}
                caps.
              </Badge>
              <Button asChild size="sm">
                <a href={episodes[0]!.link} target="_blank" rel="noreferrer">
                  Leer capítulo 1
                </a>
              </Button>
            </div>
          )}
        </div>
      </section>

      <div className="px-6 md:px-12">
        <Tabs value={tab} onValueChange={setTab}>
          <TabsList>
            <TabsTrigger value="generar">Generar videos</TabsTrigger>
            <TabsTrigger value="vinetas">Viñetas ({panels.length})</TabsTrigger>
            <TabsTrigger value="plantillas">Plantillas Virales</TabsTrigger>
            <TabsTrigger value="capitulos">Capítulos ({episodes.length})</TabsTrigger>
          </TabsList>

          <TabsContent value="generar" className="space-y-8 pt-4">
            <div className="flex flex-wrap items-end gap-6 rounded-lg border border-border bg-card p-5">
              <div className="space-y-2">
                <Label>Cantidad de videos</Label>
                <div className="flex gap-1">
                  {[1, 3, 5].map((n) => (
                    <Button
                      key={n}
                      variant={count === n ? "default" : "secondary"}
                      size="sm"
                      onClick={() => setCount(n)}
                    >
                      {n}
                    </Button>
                  ))}
                </div>
              </div>
              <div className="min-w-[240px] space-y-2">
                <Label>Objetivo del video</Label>
                <Select value={goal} onValueChange={(v) => setGoal(v as Goal)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {GOALS.map((g) => (
                      <SelectItem key={g.id} value={g.id}>
                        {g.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <Button size="lg" onClick={generate}>
                <Sparkles className="mr-1 h-4 w-4" />
                Generar lote
              </Button>
              <div className="w-full space-y-2 sm:w-56">
                <Label>Duración objetivo</Label>
                <Select
                  value={String(duration)}
                  onValueChange={(value) => setDuration(Number(value) as ScriptDuration)}
                >
                  <SelectTrigger aria-label="Duración objetivo">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {SCRIPT_DURATIONS.map((item) => (
                      <SelectItem key={item.id} value={String(item.id)}>
                        {item.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="w-full space-y-2 sm:w-64">
                <Label>Plantilla del guion</Label>
                <Select value={templateId} onValueChange={setTemplateId}>
                  <SelectTrigger aria-label="Plantilla del guion">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="original">Guion original</SelectItem>
                    {templates.map((t) => (
                      <SelectItem key={t.id} value={t.id}>
                        {t.name}
                        {t.classification === "10k" ? " · +10k" : ""}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="w-full space-y-2 sm:w-56">
                <Label>Estilo de narración</Label>
                <Select
                  value={style}
                  onValueChange={(value) => {
                    if (value === "accion" || value === "epico" || value === "misterio")
                      setStyle(value);
                  }}
                >
                  <SelectTrigger aria-label="Estilo del nuevo lote">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {NARRATION_STYLES.map((s) => (
                      <SelectItem key={s.id} value={s.id}>
                        {s.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {videos.length > 0 && (
              <Tabs value={active} onValueChange={setActive}>
                <TabsList>
                  {videos.map((v, i) => (
                    <TabsTrigger key={v.id} value={v.id}>
                      Video {i + 1}
                    </TabsTrigger>
                  ))}
                </TabsList>
                {videos.map((v) => (
                  <TabsContent key={v.id} value={v.id} className="grid gap-8 pt-4 xl:grid-cols-2">
                    <div className="space-y-3">
                      <h3 className="font-display text-3xl tracking-wide">Editor de escenas</h3>
                      {v.templateName && <Badge variant="secondary">{v.templateName}</Badge>}
                      {v.lines.map((l, i) => {
                        const p = l.panelId ? panelById.get(l.panelId) : null;
                        return (
                          <div
                            key={l.id}
                            className="flex gap-3 rounded-lg border border-border bg-card p-3"
                          >
                            <button
                              onClick={() => setPicker({ video: v.id, line: l.id })}
                              className="h-28 w-20 shrink-0 overflow-hidden rounded bg-muted ring-primary hover:ring-2"
                              title="Cambiar viñeta"
                            >
                              {p && (
                                <img
                                  src={img(p.path, work.source_url)}
                                  alt=""
                                  className="h-full w-full object-cover object-top"
                                />
                              )}
                            </button>
                            <div className="flex-1 space-y-2">
                              <div className="flex gap-2">
                                <Badge>
                                  {i + 1}. {BEAT_LABEL[l.beat]}
                                </Badge>
                                <Badge variant="secondary">
                                  {TAGS.find((t) => t.id === l.tag)?.label ?? l.tag}
                                </Badge>
                              </div>
                              <Textarea
                                value={l.text}
                                rows={2}
                                onChange={(e) =>
                                  updateLine(v.id, l.id, {
                                    text: e.target.value,
                                    tag: inferTag(e.target.value),
                                  })
                                }
                              />
                            </div>
                          </div>
                        );
                      })}
                    </div>
                    <div>
                      <h3 className="mb-3 font-display text-3xl tracking-wide">
                        Vista previa 9:16
                      </h3>
                      <Player
                        video={v}
                        panels={panels}
                        referer={work.source_url}
                        title={work.title}
                        index={videos.indexOf(v) + 1}
                      />
                      <div className="mt-4 space-y-3 rounded-lg border border-border bg-card p-4">
                        <h4 className="font-display text-2xl tracking-wide">
                          Resultados en YouTube
                        </h4>
                        <div className="grid grid-cols-2 gap-3">
                          {(
                            [
                              ["views", "Visitas"],
                              ["retention", "Retención media (%)"],
                              ["avgSeconds", "Duración media vista (s)"],
                              ["likes", "Likes"],
                            ] as const
                          ).map(([k, label]) => (
                            <div key={k} className="space-y-1">
                              <Label>{label}</Label>
                              <Input
                                type="number"
                                min={0}
                                value={v.stats?.[k] ?? ""}
                                onChange={(e) =>
                                  setStats(v.id, {
                                    [k]: e.target.value === "" ? undefined : Number(e.target.value),
                                  })
                                }
                              />
                            </div>
                          ))}
                          <div className="col-span-2 space-y-1">
                            <Label>Fecha de publicación</Label>
                            <Input
                              type="date"
                              value={v.stats?.publishedAt ?? ""}
                              onChange={(e) => setStats(v.id, { publishedAt: e.target.value })}
                            />
                          </div>
                          <div className="col-span-2 space-y-1">
                            <Label>¿Dónde cae la retención? (ej. «cae en el seg 4»)</Label>
                            <Textarea
                              rows={2}
                              value={v.stats?.note ?? ""}
                              onChange={(e) => setStats(v.id, { note: e.target.value })}
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </TabsContent>
                ))}
              </Tabs>
            )}
          </TabsContent>

          <TabsContent value="capitulos" className="pt-4">
            {episodes.length === 0 ? (
              <p className="text-muted-foreground">No hay lista de capítulos para esta obra.</p>
            ) : (
              <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
                {[...episodes].reverse().map((e) => (
                  <a
                    key={e.no}
                    href={e.link}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center justify-between rounded-lg border border-border bg-card p-3 hover:border-primary"
                  >
                    <span className="font-semibold">{e.title}</span>
                    <span className="text-sm text-muted-foreground">{fmtDate(e.date)} · Leer</span>
                  </a>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="plantillas" className="pt-6">
            <TemplateBank
              onApply={(t) => {
                setTemplateId(t.id);
                setTab("generar");
                toast.success(`Plantilla «${t.name}» seleccionada`);
              }}
            />
          </TabsContent>

          <TabsContent value="vinetas" className="pt-4">
            <p className="mb-4 text-sm text-muted-foreground">
              Opcional: añade una etiqueta o pocas palabras ("aventureros riendo", "recepcionista")
              para que el emparejamiento sea aún más preciso.
            </p>
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
              {panels.map((p) => (
                <div key={p.id} className="space-y-2 rounded-lg border border-border bg-card p-2">
                  <img
                    src={img(p.path, work.source_url)}
                    alt=""
                    loading="lazy"
                    className="aspect-[3/4] w-full rounded object-cover object-top"
                  />
                  <Select value={p.tag} onValueChange={(tag) => updatePanel(p, { tag })}>
                    <SelectTrigger className="h-8">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {TAGS.map((t) => (
                        <SelectItem key={t.id} value={t.id}>
                          {t.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <div className="flex gap-1">
                    <Input
                      className="h-8"
                      defaultValue={p.description}
                      placeholder="¿Qué se ve?"
                      onBlur={(e) =>
                        e.target.value !== p.description &&
                        updatePanel(p, { description: e.target.value })
                      }
                    />
                    <Button
                      size="icon"
                      variant="ghost"
                      className="h-8 w-8"
                      onClick={() => deletePanel(p)}
                      aria-label="Quitar"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>

      <Dialog open={!!picker} onOpenChange={(o) => !o && setPicker(null)}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>Elige la viñeta para esta frase</DialogTitle>
          </DialogHeader>
          <div className="grid max-h-[70vh] grid-cols-3 gap-2 overflow-y-auto sm:grid-cols-5">
            {panels.map((p) => (
              <button
                key={p.id}
                onClick={() => {
                  if (picker) updateLine(picker.video, picker.line, { panelId: p.id });
                  setPicker(null);
                }}
                className="overflow-hidden rounded ring-primary hover:ring-2"
              >
                <img
                  src={img(p.path, work.source_url)}
                  alt=""
                  loading="lazy"
                  className="aspect-[3/4] w-full object-cover object-top"
                />
              </button>
            ))}
          </div>
        </DialogContent>
      </Dialog>
    </main>
  );
}
