import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { Loader2, Link2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { CATEGORIES, img } from "@/lib/catalog";
import { extractChapter } from "@/lib/extract.functions";
import { importMangaDex } from "@/lib/mangadex.functions";
import { SEASONS, type SeasonId } from "@/lib/seasons";

export const Route = createFileRoute("/nueva")({
  head: () => ({
    meta: [
      { title: "Añadir obra — SamuManga" },
      {
        name: "description",
        content: "Pega el enlace de un capítulo y extrae sus viñetas automáticamente.",
      },
      { property: "og:title", content: "Añadir obra — SamuManga" },
      {
        property: "og:description",
        content: "Extrae viñetas de un capítulo de webtoon para crear videos.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: NewWork,
});

const FIELDS = [
  [
    "premise",
    "Premisa (gancho)",
    "despertar en un mundo lleno de monstruos con la habilidad de controlar una simple rata",
  ],
  [
    "conflict",
    "Conflicto",
    "Todos se burlan de nuestro protagonista, porque mientras los demás invocan dragones, él solo puede llamar a una rata.",
  ],
  [
    "reveal",
    "Revelación",
    "Cuando entra a una mazmorra y aparece un monstruo imposible, la rata comienza a transformarse. Se convierte en el Rey de las Bestias.",
  ],
  [
    "climax",
    "Clímax",
    "Llega al gremio a vender los cristales y el gerente queda sorprendido. Los aventureros lo acusan de hacer trampa.",
  ],
  [
    "twist",
    "Remate",
    "El protagonista le susurra que la próxima vez no tendrá tanta suerte. La habilidad más inútil podría ser la más peligrosa.",
  ],
] as const;

function NewWork() {
  const extract = useServerFn(extractChapter);
  const importMangaDexChapter = useServerFn(importMangaDex);
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [url, setUrl] = useState("");
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [images, setImages] = useState<string[]>([]);
  const [cover, setCover] = useState("");
  const [season, setSeason] = useState<SeasonId>("all");
  const [form, setForm] = useState({
    title: "",
    category: CATEGORIES[0] as string,
    protagonist: "nuestro protagonista",
    synopsis: "",
    premise: "",
    conflict: "",
    reveal: "",
    climax: "",
    twist: "",
  });
  const set = (k: keyof typeof form, v: string) => setForm((f) => ({ ...f, [k]: v }));

  async function onExtract() {
    setLoading(true);
    try {
      const uuid = "[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}";
      const mangaId =
        url.match(new RegExp(`(?:title|manga)/(${uuid})`, "i"))?.[1] ??
        url.match(new RegExp(`^${uuid}$`, "i"))?.[0];
      const r = mangaId
        ? await importMangaDexChapter({ data: { mangaId } })
        : await extract({ data: { url } });
      if (!r.ok) {
        toast.error(r.error);
        return;
      }
      setImages(r.images);
      setCover(r.cover);
      if (!form.title && r.title) set("title", (r.title.split(/[|\-–]/)[0] ?? "").trim());
      if ("synopsis" in r && r.synopsis && !form.synopsis) set("synopsis", r.synopsis);
      toast.success(`${r.images.length} viñetas encontradas`);
    } catch (e) {
      toast.error("No se pudo leer esa página.");
    } finally {
      setLoading(false);
    }
  }

  async function onSave() {
    if (!form.title || images.length === 0) {
      toast.error("Falta el título o las viñetas.");
      return;
    }
    setSaving(true);
    const { data: auth } = await supabase.auth.getUser();
    if (!auth.user) {
      toast.error("Inicia sesión para guardar obras.");
      setSaving(false);
      return;
    }
    const { data, error } = await supabase
      .from("works")
      .insert({
        ...form,
        owner_id: auth.user.id,
        season,
        cover_path: cover || images[0] || null,
        source_url: url,
      })
      .select("id")
      .single();
    if (error || !data) {
      setSaving(false);
      toast.error("No se pudo guardar la obra.");
      return;
    }
    const { error: pe } = await supabase
      .from("panels")
      .insert(images.map((path, position) => ({ work_id: data.id, path, position })));
    setSaving(false);
    if (pe) {
      toast.error("La obra se guardó, pero fallaron las viñetas.");
    }
    await qc.invalidateQueries({ queryKey: ["works"] });
    navigate({ to: "/obra/$id", params: { id: data.id } });
  }

  return (
    <main className="mx-auto max-w-5xl px-6 pb-20 pt-28">
      <h1 className="font-display text-5xl tracking-wide">Añadir obra</h1>
      <p className="mt-2 text-muted-foreground">
        Pega un capítulo de Webtoon o un enlace/UUID de título de MangaDex. Las imágenes se muestran
        mediante el proxy `/api/img`.
      </p>

      <div className="mt-6 flex gap-2">
        <Input
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          placeholder="Webtoon URL o https://mangadex.org/title/UUID"
        />
        <Button onClick={onExtract} disabled={!url || loading}>
          {loading ? (
            <Loader2 className="mr-1 h-4 w-4 animate-spin" />
          ) : (
            <Link2 className="mr-1 h-4 w-4" />
          )}
          Extraer viñetas
        </Button>
      </div>

      {images.length > 0 && (
        <>
          <p className="mt-6 text-sm text-muted-foreground">
            Toca una viñeta para usarla como portada.
          </p>
          <div className="no-scrollbar mt-2 flex gap-2 overflow-x-auto pb-2">
            {images.map((src) => (
              <button
                key={src}
                onClick={() => setCover(src)}
                className={`h-40 w-24 shrink-0 overflow-hidden rounded border-2 ${cover === src ? "border-primary" : "border-transparent"}`}
              >
                <img
                  src={img(src, url)}
                  alt=""
                  loading="lazy"
                  className="h-full w-full object-cover object-top"
                />
              </button>
            ))}
          </div>

          <div className="mt-8 grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label>Título</Label>
              <Input value={form.title} onChange={(e) => set("title", e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>Categoría</Label>
              <Select value={form.category} onValueChange={(v) => set("category", v)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {CATEGORIES.map((c) => (
                    <SelectItem key={c} value={c}>
                      {c}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Temporada</Label>
              <Select value={season} onValueChange={(value) => setSeason(value as SeasonId)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {SEASONS.map((item) => (
                    <SelectItem key={item.id} value={item.id}>
                      {item.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2 md:col-span-2">
              <Label>Sinopsis corta</Label>
              <Textarea value={form.synopsis} onChange={(e) => set("synopsis", e.target.value)} />
            </div>
            <p className="text-sm text-muted-foreground md:col-span-2">
              Cuéntame la historia por partes; el guion se arma con este ritmo y cada frase se
              empareja con la viñeta adecuada.
            </p>
            {FIELDS.map(([k, label, ph]) => (
              <div key={k} className="space-y-2 md:col-span-2">
                <Label>{label}</Label>
                <Textarea
                  value={form[k]}
                  placeholder={ph}
                  onChange={(e) => set(k, e.target.value)}
                />
              </div>
            ))}
          </div>
          <Button className="mt-6" size="lg" onClick={onSave} disabled={saving}>
            {saving && <Loader2 className="mr-1 h-4 w-4 animate-spin" />}Guardar en el catálogo
          </Button>
        </>
      )}
    </main>
  );
}
