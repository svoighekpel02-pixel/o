import { createFileRoute } from "@tanstack/react-router";

// Image proxy: webtoon CDNs block hotlinking; we resend with the chapter as Referer
// and return the bytes same-origin so the canvas player can draw them.
export const Route = createFileRoute("/api/img")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const u = new URL(request.url);
        const target = u.searchParams.get("u");
        const ref = u.searchParams.get("r") ?? "";
        if (!target || !/^https?:\/\//.test(target)) return new Response("bad url", { status: 400 });
        const res = await fetch(target, {
          headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/128.0 Safari/537.36",
            Referer: ref || new URL(target).origin + "/",
            Accept: "image/avif,image/webp,image/*,*/*",
          },
        });
        const type = res.headers.get("content-type") ?? "";
        if (!res.ok || !type.startsWith("image/")) return new Response("not an image", { status: 502 });
        return new Response(res.body, {
          headers: { "content-type": type, "cache-control": "public, max-age=604800" },
        });
      },
    },
  },
});
