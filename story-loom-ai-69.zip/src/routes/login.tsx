import { createFileRoute } from "@tanstack/react-router";
import { AuthPanel } from "@/components/AuthPanel";

export const Route = createFileRoute("/login")({
  head: () => ({ meta: [{ title: "Entrar — SamuManga" }] }),
  component: AuthPanel,
});
