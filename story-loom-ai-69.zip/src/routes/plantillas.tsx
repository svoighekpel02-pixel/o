import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { useState } from "react";
import { TemplateBank } from "@/components/TemplateBank";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { worksQuery } from "@/lib/catalog";
import type { ScriptTemplate } from "@/lib/templates";

export const Route = createFileRoute("/plantillas")({
  head: () => ({ meta: [
    { title: "Plantillas Virales — SamuManga" },
    { name: "description", content: "Banco personal de guiones de referencia y plantillas adaptables para shorts de Webtoon." },
    { property: "og:title", content: "Plantillas Virales — SamuManga" },
    { property: "og:description", content: "Guarda referencias, clasifica templates +10k y adapta su estructura a tus obras." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ] }),
  loader: ({ context }) => context.queryClient.ensureQueryData(worksQuery()),
  component: TemplatesPage,
});

function TemplatesPage() {
  const { data: works } = useSuspenseQuery(worksQuery());
  const navigate = useNavigate();
  const [selected, setSelected] = useState<ScriptTemplate | null>(null);
  const [workId, setWorkId] = useState("");
  return <main className="mx-auto max-w-6xl px-6 pb-20 pt-28 md:px-12">
    <TemplateBank onApply={(t) => { setSelected(t); setWorkId(works[0]?.id ?? ""); }} />
    <Dialog open={selected !== null} onOpenChange={(open) => { if (!open) setSelected(null); }}>
      <DialogContent><DialogHeader><DialogTitle>Aplicar {selected?.name}</DialogTitle></DialogHeader>
        <Label>Obra</Label>
        {works.length ? <Select value={workId} onValueChange={setWorkId}><SelectTrigger aria-label="Obra para plantilla"><SelectValue /></SelectTrigger><SelectContent>{works.map((w) => <SelectItem key={w.id} value={w.id}>{w.title}</SelectItem>)}</SelectContent></Select> : <p className="text-muted-foreground">No hay obras en tu catálogo.</p>}
        <Button disabled={!workId} onClick={() => { if (selected) navigate({ to: "/obra/$id", params: { id: workId }, search: { template: selected.id } }); }}>Ir a generar shorts</Button>
      </DialogContent>
    </Dialog>
  </main>;
}