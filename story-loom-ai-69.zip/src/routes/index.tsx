import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { useEffect, useRef, useState } from "react";
import { ChevronLeft, ChevronRight, Play, Plus } from "lucide-react";
import { WebtoonRows } from "@/components/WebtoonRows";
import { CATEGORIES, img, worksQuery, type Work } from "@/lib/catalog";
import { loadSeason, matchesSeason, saveSeason, SEASONS, type SeasonId } from "@/lib/seasons";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "SamuManga — Catálogo de webtoons para videos" },
      {
        name: "description",
        content:
          "Catálogo estilo Netflix de manhwas y webtoons para generar videos verticales con guion y voz.",
      },
      { property: "og:title", content: "SamuManga — Catálogo de webtoons para videos" },
      {
        property: "og:description",
        content:
          "Elige una obra, genera guiones por lote y crea videos 9:16 sincronizados con sus viñetas.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(worksQuery()),
  component: Catalog,
});

function Catalog() {
  const { data: works } = useSuspenseQuery(worksQuery());
  const [season, setSeason] = useState<SeasonId>("all");
  useEffect(() => setSeason(loadSeason()), []);
  const seasonalWorks = works.filter((work) => matchesSeason(work, season));
  const featured = seasonalWorks[0];

  if (!featured) {
    return (
      <>
        <main className="flex min-h-[70vh] flex-col items-center justify-center gap-6 px-6 text-center">
          <h1 className="font-display text-6xl tracking-wide md:text-8xl">
            Tu catálogo está vacío
          </h1>
          <p className="max-w-lg text-muted-foreground">
            Pega el enlace de un capítulo y la app extraerá sus viñetas automáticamente para empezar
            a crear videos.
          </p>
          <Link
            to="/nueva"
            className="inline-flex items-center gap-2 rounded bg-primary px-6 py-3 font-semibold text-primary-foreground hover:bg-primary/90"
          >
            <Plus className="h-5 w-5" /> Añadir primera obra
          </Link>
        </main>
        <div className="pb-16">
          <WebtoonRows works={works} />
        </div>
      </>
    );
  }

  return (
    <main className="min-h-screen pb-16">
      <section className="relative h-[80vh] min-h-[520px] w-full overflow-hidden">
        <img
          src={img(featured.cover_path, featured.source_url)}
          alt={featured.title}
          className="absolute inset-0 h-full w-full object-cover object-top"
        />
        <div className="absolute inset-0" style={{ background: "var(--gradient-side)" }} />
        <div className="absolute inset-0" style={{ background: "var(--gradient-hero)" }} />
        <div className="relative flex h-full max-w-2xl flex-col justify-end gap-4 px-6 pb-24 md:px-12">
          <span className="text-sm font-semibold uppercase tracking-[0.3em] text-primary">
            {featured.category}
          </span>
          <h1 className="font-display text-6xl leading-none tracking-wide md:text-8xl">
            {featured.title}
          </h1>
          <p className="line-clamp-3 text-lg text-muted-foreground">
            {featured.synopsis || featured.premise}
          </p>
          <div className="flex gap-3">
            <Link
              to="/obra/$id"
              params={{ id: featured.id }}
              className="inline-flex items-center gap-2 rounded bg-foreground px-6 py-3 font-semibold text-background hover:bg-foreground/85"
            >
              <Play className="h-5 w-5 fill-current" /> Crear videos
            </Link>
          </div>
        </div>
      </section>
      <div className="-mt-16 relative space-y-10">
        <div className="mx-6 flex max-w-sm items-center gap-3 rounded-2xl border border-white/10 bg-black/40 p-3 backdrop-blur-xl md:mx-12">
          <span className="text-sm font-semibold">Temporada</span>
          <Select
            value={season}
            onValueChange={(value) => {
              const next = value as SeasonId;
              setSeason(next);
              saveSeason(next);
            }}
          >
            <SelectTrigger aria-label="Temporada activa">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {SEASONS.map((item) => (
                <SelectItem key={item.id} value={item.id}>
                  {item.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <WebtoonRows works={seasonalWorks} />
        {CATEGORIES.map((c) => (
          <Row key={c} title={c} works={seasonalWorks.filter((w) => w.category === c)} />
        ))}
      </div>
    </main>
  );
}

function Row({ title, works }: { title: string; works: Work[] }) {
  const ref = useRef<HTMLDivElement>(null);
  if (works.length === 0) return null;
  const scroll = (d: number) =>
    ref.current?.scrollBy({ left: d * ref.current.clientWidth * 0.8, behavior: "smooth" });
  return (
    <section className="group/row relative">
      <h2 className="mb-3 px-6 text-xl font-semibold md:px-12">{title}</h2>
      <button
        onClick={() => scroll(-1)}
        aria-label="Anterior"
        className="absolute left-0 top-10 z-10 hidden h-[calc(100%-2.5rem)] w-10 items-center justify-center bg-background/60 group-hover/row:flex"
      >
        <ChevronLeft />
      </button>
      <div
        ref={ref}
        className="no-scrollbar flex gap-3 overflow-x-auto scroll-smooth px-6 md:px-12"
      >
        {works.map((w) => (
          <Link
            key={w.id}
            to="/obra/$id"
            params={{ id: w.id }}
            className="group relative w-40 shrink-0 md:w-48"
          >
            <div className="aspect-[2/3] overflow-hidden rounded-md bg-card transition-transform duration-300 group-hover:scale-105">
              <img
                src={img(w.cover_path, w.source_url)}
                alt={w.title}
                loading="lazy"
                className="h-full w-full object-cover"
              />
            </div>
            <div className="mt-2">
              <p className="truncate text-sm font-semibold">{w.title}</p>
              <p className="line-clamp-2 text-xs text-muted-foreground">
                {w.premise || w.synopsis}
              </p>
            </div>
          </Link>
        ))}
      </div>
      <button
        onClick={() => scroll(1)}
        aria-label="Siguiente"
        className="absolute right-0 top-10 z-10 hidden h-[calc(100%-2.5rem)] w-10 items-center justify-center bg-background/60 group-hover/row:flex"
      >
        <ChevronRight />
      </button>
    </section>
  );
}
