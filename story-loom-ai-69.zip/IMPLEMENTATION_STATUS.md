# StoryLoom / SamuManga — estado de implementación

## Rama y validación

- Rama: `feat/storyloom-expansion`
- La rama parte de `main` sin cambios locales.
- `bun run test`: 21 pruebas pasan en la verificación de Fase 0; después se añadieron 2 pruebas simuladas de MangaDex.
- `bun run build`: pasa.
- `bun run lint`: el repositorio ya tenía cientos de errores de Prettier en archivos no tocados. Los archivos de esta fase se formatearon de forma aislada; no se reformateó todo el proyecto para evitar un commit masivo no funcional.

## Hecho en esta fase

1. **Cuenta Supabase**: nueva ruta `/login` con correo y contraseña, registro, sesión persistente, correo visible en la cabecera y salida.
2. **Aislamiento de datos**: migración `supabase/migrations/20261016_storyloom_accounts_seasons.sql` con `owner_id`, temporada, índices y políticas RLS para `works` y `panels`. Hay que aplicarla en Supabase antes de usar el guardado por usuario.
3. **Temporadas**: `src/lib/seasons.ts` define Halloween, Navidad, San Valentín, Año nuevo y verano. La selección se conserva en el navegador y permite cambiar manualmente. También se acepta coincidencia por palabras clave para obras sin metadato explícito.
4. **Duraciones deterministas**: el motor ofrece 15 s, 45 s y 90 s mediante perfiles de palabras/líneas y exporta `REFERENCE_SCRIPTS` como contrato de referencia. No se usa ninguna API generativa.
5. **Interfaz**: se añadió una capa visual oscura/glassmorphism, foco visible y contraste conservado.

## Configuración pendiente de esta fase

- Aplicar la migración desde el dashboard de Supabase o con `supabase db push`.
- Activar Email/Password en Supabase Auth y configurar la URL de redirección de producción.
- Revisar y asociar obras existentes a un `owner_id` antes de activar RLS si ya hay datos históricos.
- Mantener `VITE_SUPABASE_URL` y `VITE_SUPABASE_PUBLISHABLE_KEY` en Vercel; nunca subir `.env`.

## Fuentes y decisiones legales

- MangaDex es una API pública válida para metadatos, pero exige `User-Agent`, proxy de imágenes y aproximadamente 5 solicitudes por segundo por IP. La integración debe respetar esos límites.
- AniList no es una opción segura para este producto comercial sin revisar licencia: sus términos prohíben usarla como almacenamiento masivo y exigen licencia por encima de 150 USD/mes.
- WEBTOON prohíbe el crawling/scraping automatizado no autorizado. Tapas también restringe sistemas automatizados. No se implementó una nueva extracción para esas plataformas.
- Pixabay permite uso gratuito y adaptación, pero obliga a revisar derechos adicionales y usos prohibidos por pista. El repositorio aún no descarga nuevas pistas porque falta seleccionar y verificar cada licencia/autoria.
- YouTube considera problemático el contenido repetitivo o producido en masa para monetización. La app debe conservar narración, edición y comentario sustancialmente distintos por video.

## No terminado todavía

- La integración MangaDex ya está implementada en `src/lib/mangadex.functions.ts`: búsqueda, feed en español, capítulos, at-home, caché de 5 minutos, cola aproximada de 5 solicitudes por segundo y reintentos ante 429. La extracción real depende de red y credenciales no son necesarias; la prueba automática usa respuestas simuladas.
- Biblioteca de música funk/estilos y efectos/memes con archivos descargados, licencia, autor y panel de disparadores.
- Optimización medida de exportación. El reproductor sigue usando `MediaRecorder` en tiempo real; no hay benchmark reproducible antes/después aún.
- OAuth de Google/YouTube, estadísticas, metas, subida y programación. Requiere registrar un cliente OAuth en Google Cloud, secretos de servidor y almacenamiento seguro de refresh tokens. No se puede completar responsablemente sin esa configuración.
- No se ha subido ningún video ni se ha creado automatización de publicación.

El manifiesto `src/lib/media-manifest.ts` deja una entrada de música Pixabay como `pending`, sin archivo ni ruta inventada. No se habilita ningún recurso nuevo hasta verificar una pista concreta, su autor, URL, licencia y permiso comercial.

## Prueba manual de lo implementado

1. Ejecuta `bun install --frozen-lockfile` y `bun run dev`.
2. Abre `/login`, crea/inicia sesión y confirma que la cabecera muestra el correo.
3. Abre `/nueva`, extrae una obra, selecciona temporada y guárdala.
4. En el catálogo cambia la temporada manualmente y comprueba el filtrado.
5. En una obra abre Generar videos, cambia entre 15 s, 45 s y 1:30 y genera un lote.
6. Ejecuta `bun run test` y `bun run build`.
