make manga short 
