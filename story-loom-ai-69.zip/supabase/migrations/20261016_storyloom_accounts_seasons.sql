-- StoryLoom phase 1: account ownership and seasonal catalog metadata.
alter table public.works add column if not exists owner_id uuid references auth.users(id) on delete cascade;
alter table public.works add column if not exists season text not null default 'all';

create index if not exists works_owner_id_idx on public.works(owner_id);
create index if not exists works_season_idx on public.works(season);

alter table public.works enable row level security;
alter table public.panels enable row level security;

drop policy if exists "authenticated users can read own works" on public.works;
create policy "authenticated users can read own works" on public.works
  for select to authenticated using (owner_id = auth.uid());

drop policy if exists "authenticated users can insert own works" on public.works;
create policy "authenticated users can insert own works" on public.works
  for insert to authenticated with check (owner_id = auth.uid());

drop policy if exists "authenticated users can update own works" on public.works;
create policy "authenticated users can update own works" on public.works
  for update to authenticated using (owner_id = auth.uid()) with check (owner_id = auth.uid());

drop policy if exists "authenticated users can delete own works" on public.works;
create policy "authenticated users can delete own works" on public.works
  for delete to authenticated using (owner_id = auth.uid());

drop policy if exists "authenticated users can read panels for own works" on public.panels;
create policy "authenticated users can read panels for own works" on public.panels
  for select to authenticated using (exists (select 1 from public.works w where w.id = panels.work_id and w.owner_id = auth.uid()));

drop policy if exists "authenticated users can insert panels for own works" on public.panels;
create policy "authenticated users can insert panels for own works" on public.panels
  for insert to authenticated with check (exists (select 1 from public.works w where w.id = panels.work_id and w.owner_id = auth.uid()));

drop policy if exists "authenticated users can update panels for own works" on public.panels;
create policy "authenticated users can update panels for own works" on public.panels
  for update to authenticated using (exists (select 1 from public.works w where w.id = panels.work_id and w.owner_id = auth.uid())) with check (exists (select 1 from public.works w where w.id = panels.work_id and w.owner_id = auth.uid()));

drop policy if exists "authenticated users can delete panels for own works" on public.panels;
create policy "authenticated users can delete panels for own works" on public.panels
  for delete to authenticated using (exists (select 1 from public.works w where w.id = panels.work_id and w.owner_id = auth.uid()));
