CREATE TABLE public.works (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  category text NOT NULL DEFAULT 'Protagonistas rotos',
  synopsis text NOT NULL DEFAULT '',
  protagonist text NOT NULL DEFAULT 'nuestro protagonista',
  premise text NOT NULL DEFAULT '',
  conflict text NOT NULL DEFAULT '',
  reveal text NOT NULL DEFAULT '',
  climax text NOT NULL DEFAULT '',
  twist text NOT NULL DEFAULT '',
  cover_path text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.works TO anon, authenticated;
GRANT ALL ON public.works TO service_role;
ALTER TABLE public.works ENABLE ROW LEVEL SECURITY;
CREATE POLICY "works open" ON public.works FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

CREATE TABLE public.panels (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  work_id uuid NOT NULL REFERENCES public.works(id) ON DELETE CASCADE,
  path text NOT NULL,
  position int NOT NULL DEFAULT 0,
  tag text NOT NULL DEFAULT 'escena',
  description text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.panels TO anon, authenticated;
GRANT ALL ON public.panels TO service_role;
ALTER TABLE public.panels ENABLE ROW LEVEL SECURITY;
CREATE POLICY "panels open" ON public.panels FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

CREATE POLICY "panels bucket read" ON storage.objects FOR SELECT TO anon, authenticated USING (bucket_id = 'panels');
CREATE POLICY "panels bucket write" ON storage.objects FOR INSERT TO anon, authenticated WITH CHECK (bucket_id = 'panels');
CREATE POLICY "panels bucket delete" ON storage.objects FOR DELETE TO anon, authenticated USING (bucket_id = 'panels');