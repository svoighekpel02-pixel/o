DROP POLICY IF EXISTS "panels bucket read" ON storage.objects;
DROP POLICY IF EXISTS "panels bucket write" ON storage.objects;
DROP POLICY IF EXISTS "panels bucket delete" ON storage.objects;