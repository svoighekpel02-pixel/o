ALTER TABLE public.works ADD COLUMN source_url text;
COMMENT ON COLUMN public.panels.path IS 'Remote image URL extracted from the chapter page';